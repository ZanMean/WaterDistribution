<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Themsp.css"/>
    <link rel="stylesheet" href="./design/Lapphieu.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./java/Switch.js"></script>
    <title>Phiếu xuất hàng</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title"></p>
                </div>
                <div class="body_right_top_right" id="right-1"> 
                    <button class="return-btn" id="return" name="reset" type="reset" onclick="document.location='Kho.php'">Quay về</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="add-new-item-box">
                    <div class="item-box-title">
                        <p>PHIẾU XUẤT HÀNG</p>
                    </div>
                    <div class="box-form-XH-content">
                        <?php
                            $id=$_GET['id']; 
                            $PXH_find_query = "select * from phieuxuathang where PXH_id=$id";
                            $PXH_find_result = mysqli_query($con, $PXH_find_query) or die(mysqli_error($con));
                            $row1 = mysqli_fetch_assoc($PXH_find_result);
                            $DL_id = $row1['DL_id'];
                            $find_DL_query = "select * from daily where DL_id = '$DL_id'";
                            $find_DL_result = mysqli_query($con, $find_DL_query) or die(mysqli_error($con));
                            $row2 = mysqli_fetch_assoc($find_DL_result);
                        ?>
                        <div class="item-group-container-top">
                            <div class="item-group-XH">
                                <label class="item-name">Đại lý:</label><br>
                                <input type="text" name="TenDL" id="" class="itemXH-text-box" value="<?php echo $row2['TenDL'] ?>" disabled>
                            </div>
                        </div>
                        <div class="item-group-container-body">
                            <table class="out-table">
                                <tr>
                                    <th class="xuat-col-1">STT</th>
                                    <th class="xuat-col-2">Mặt hàng</th>
                                    <th class="xuat-col-3">Đơn vị tính</th>
                                    <th class="xuat-col-4">Số lượng</th>
                                    <th class="xuat-col-5">Đơn giá</th>
                                    <th class="xuat-col-6">Thành tiền</th>
                                </tr>
                                <?php
                                    $stt = 1;
                                    $find_CTXH_query = "SELECT * FROM chitietxuathang WHERE PXH_id=$id";
                                    $find_CTXH_result = mysqli_query($con,$find_CTXH_query) or die(mysqli_error($con));
                                    while ($row3 = mysqli_fetch_assoc($find_CTXH_result))
                                    {
                                        $Sp_id = $row3['Sp_id'];
                                        $findname_SP_query = "SELECT * FROM sanpham WHERE Sp_id='$Sp_id'";
                                        $findname_SP_result = mysqli_query($con,$findname_SP_query) or die(mysqli_error($con));
                                        $row4 = mysqli_fetch_assoc($findname_SP_result);
                                        $TenSP = $row4['TenSP'];
                                        $DonviXH = $row3['DonviXH'];
                                        switch($DonviXH)
                                        {
                                            case 'Ket':
                                            {
                                                $GiaSP = $row4['GiaketSP'];
                                                break;
                                            }
                                            case 'Loc':
                                            {
                                                $GiaSP = $row4['GialocSP'];
                                                break;
                                            }
                                            case 'Thung':
                                            {
                                                $GiaSP = $row4['GiathungSP'];
                                                break;
                                            }
                                        }
                                        ?>
                                        <tr>
                                            <td class="xuat-col-1"><?php echo $stt?></td>
                                            <td class="xuat-col-2"><?php echo $TenSP; ?></td>
                                            <td class="xuat-col-3"><?php echo $row3['DonviXH']; ?></td>
                                            <td class="xuat-col-4"><?php echo $row3['SoluongXH']; ?></td>
                                            <td class="xuat-col-5"><?php echo $GiaSP;?></td>
                                            <td class="xuat-col-6"><?php echo $row3['ThanhtienXH']; ?></td>
                                            <input type="hidden" name="thanhtiensp[]" id="thanhtiensp<?php echo $check?>" value="">
                                        </tr>
                                        <?php
                                        $stt++;
                                    }
                                ?>
                            </table>
                        </div>
                        <div class="item-group-container-bottom">
                            <div class="item-group-XH-bottom">
                                <label class="item-name">Tổng tiền:</label>
                                <span id="count-total"><?php echo $row1['TongtienPXH'] ?></span>
                                <input id="totalvar" type="hidden" name="TongtienPXH">
                            </div>
                            <div class="item-group-XH-bottom">
                                <label class="item-name">Số tiền trả:</label>
                                <input type="text" name="SotientraPXH" id="tientra" class="XHPay-text-box" value="<?php echo $row1['SotientraPXH'] ?>" disabled>
                            </div>
                            <div class="item-group-XH-bottom">
                                <label class="item-name">Còn lại:</label>
                                <span id="conlai"><?php echo $row1['ConlaiPXH'] ?></span>
                                <input id="conlaivar" type="hidden" name="ConlaiPXH">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>