<?php
    require '../connectdb/connect.php';
    $con = ketnoi();
    $sanpham = $_POST['sanpham'];
    $donvi = $_POST['donvi'];
    $soluong = $_POST['soluong'];
    if($soluong != 0)
    {
        switch($donvi) 
        {
            case 'Ket':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $num_row = mysqli_num_rows($result);
                
                if($num_row!= 0){
                    while($row = mysqli_fetch_assoc($result)){
                        $dongia = $row["GiaketSP"];
                        $thanhtien = $dongia * $soluong;
                        echo json_encode(array($dongia,$thanhtien)); 
                    }
                }
                break;
            }
            case 'Loc':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $row = mysqli_fetch_assoc($result);
                $dongia = $row["GialocSP"];
                $thanhtien = $dongia * $soluong;
                echo json_encode(array($dongia,$thanhtien));  
                break;
            }  
            case 'Thung':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $num_row = mysqli_num_rows($result);
                
                if($num_row!= 0){
                    while($row = mysqli_fetch_assoc($result)){
                        $dongia = $row["GiathungSP"];
                        $thanhtien = $dongia * $soluong;
                        echo json_encode(array($dongia,$thanhtien)); 
                    }
                }
                break;
            } 
        }
    }
    else 
    {
        switch($donvi) 
        {
            case 'Ket':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $num_row = mysqli_num_rows($result);
                
                if($num_row!= 0){
                    while($row = mysqli_fetch_assoc($result)){
                        $dongia = $row["GiaketSP"];
                        $thanhtien = $dongia;
                        echo json_encode(array($dongia,$thanhtien));  
                    }
                }
                break;
            }
            case 'Loc':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $row = mysqli_fetch_assoc($result);
                $dongia = $row["GialocSP"];
                $thanhtien = $dongia;
                echo json_encode(array($dongia,$thanhtien)); 
                break;
            }  
            case 'Thung':
            {
                $query = "select * from sanpham where Sp_id=$sanpham";
                $result = mysqli_query($con, $query);
                $num_row = mysqli_num_rows($result);
                
                if($num_row!= 0){
                    while($row = mysqli_fetch_assoc($result)){
                        $dongia = $row["GiathungSP"];
                        $thanhtien = $dongia;
                        echo json_encode(array($dongia,$thanhtien));  
                    }
                }
                break;
            } 
        }
    }
?>