<?php
    require '../connectdb/connect.php';
    $con = ketnoi();
    $TenDL = $_POST['daily'];
    $query = "SELECT * FROM daily WHERE TenDL='$TenDL'";
    $result = mysqli_query($con, $query);
    $row = mysqli_fetch_assoc($result);
    $sdtDL = $row['sdtDL'];
    $DiaChiDL=$row['DiaChiDL'];
    $EmailDL=$row['EmailDL'];
    echo json_encode(array($sdtDL,$DiaChiDL,$EmailDL));
?>