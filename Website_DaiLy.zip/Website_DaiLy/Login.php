<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Login.css"/>
    <title>Đại Lý TMTM</title>
</head>
<body>
    <div class="container">
        <div class="infor_box">
            <div class="company_zone">
                <p class="company_text">TMTM COMPANY</p>
            </div>
            <div class="login_zone">
                <div class="login_left">
                    <h1 class="login_title">Đăng Nhập</h1>
                    <form action="" method="post">
                        <div class="login-form-group">
                            <input type="text" class="login-form-control" id="account" name="username" placeholder="Tài khoản">
                        </div>
                        <div class="login-form-group">
                            <input type="password"  class="login-form-control" id="password" name="password" placeholder="Mật khẩu">
                        </div>
                        <div class="login-form-group">
                            <input type="submit" name="submit" class="login-btn" value="Đăng Nhập">
                            <?php require './xuly/xulylogin.php'?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>