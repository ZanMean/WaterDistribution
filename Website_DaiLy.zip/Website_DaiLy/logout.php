<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    session_unset();
    session_destroy();
?>
<script>
    alert('Đăng xuất thành công');
    document.location = "Login.php";
</script>