function submitgiantiep(FormName) {
    document.getElementById(FormName).submit();
  }