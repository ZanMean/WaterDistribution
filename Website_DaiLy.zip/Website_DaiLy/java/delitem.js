function Del(name) {
    return confirm("Bạn có chắc chắn muốn xóa : " + name + " ?");
}