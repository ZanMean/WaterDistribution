<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Themsp.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Switch.js"></script>
    <script src="./java/Submitgiantiep.js"></script>
    <script>

    </script>
    <title>Đại lý</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <form action="" method="post" id="ThemDL-form">
            <div class="body_right">
                <div class="body_right_top">
                    <div class="body_right_top_left">
                        <p class="right_top_left_title"></p>
                    </div>
                    <div class="body_right_top_right" id="right-1">
                        <button class="return-btn" id="return" name="reset" type="reset" onclick="document.location='DaiLy.php'">Trở về</button>
                        <button class="save-btn" id="fix" name="startfix">Chỉnh sửa</button>
                    </div>
                    <div class="body_right_top_right" id="right-2" style="display: none;">
                        <button class="return-btn" name="cancel" type="reset" onclick="document.location='ChitietDL.php?id=<?php echo $_GET['id'];?>'">Hủy</button>
                        <button class="save-btn" name="submit" type="submit" >Lưu</button>
                    </div>
                </div>
                <div class="body_right_bottom">
                    <div class="add-new-item-box">
                        <div class="item-box-title">
                            <p>THÔNG TIN</p>
                        </div>
                        <div class="box-form-content">
                            <?php
                                $id=$_GET['id']; 
                                $CTDL_show_query = "select * from `daily` where DL_id=$id";
                                $CTDL_show_result = mysqli_query($con, $CTDL_show_query) or die(mysqli_error($con));
                                while($row= mysqli_fetch_assoc($CTDL_show_result))
                                {
                                   ?>
                                    <div class="item-group-container-left">
                                        <div class="item-group">
                                            <label class="item-name">Tên đại lý:</label><br>
                                            <input type="text" name="TenDL" id="1" class="item-text-box" value="<?php echo $row["TenDL"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Điện thoại:</label><br>
                                            <input type="text" name="sdtDL" id="2" class="item-text-box" value="<?php echo $row["sdtDL"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Quận:</label><br>
                                            <input type="text" name="QuanDL" id="3" class="item-text-box" value="<?php echo $row["QuanDL"]; ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="item-group-container-right">
                                        <div class="item-group">
                                            <label class="item-name">Loại:</label><br>
                                            <input type="text" name="LoaiDL" id="4" class="item-text-box" value="<?php echo $row["LoaiDL"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Địa chỉ:</label><br>
                                            <input type="text" name="DiaChiDL" id="5" class="item-text-box" value="<?php echo $row["DiaChiDL"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Ngày tiếp nhận:</label><br>
                                            <input type="text" name="NgayTiepNhanDL" id="6" class="item-text-box" value="<?php echo $row["NgayTiepNhanDL"]; ?>" disabled>
                                        </div>
                                    </div>
                                    <?php 
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <?php 
            if(isset($_POST['submit']))
                require './xuly/xulysuaDL.php'; 
            else if (isset($_POST['reset']))
                header('location:DaiLy.php');
            else if (isset($_POST['startfix']))
            {
                ?>
                <script>
                    document.getElementById("right-1").style.display = "none";
                    document.getElementById("right-2").style.display = "";
                    for(var i = 1; i < 7 ; i++)
                        document.getElementById(i).disabled = false;
                </script>
                <?php
            }
        ?>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>