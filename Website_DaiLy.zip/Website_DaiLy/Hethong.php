<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    if($_SESSION['username'] == "")
    {
        ?>
        <script>
            document.location = "Login.php";
        </script>
        <?php
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Hethong.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Switch.js"></script>
    <title>Hệ thống</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="account-infor-left">
                <p>
                    <span class="account-infor-title">Tài khoản: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['username'].'</span>'; 
                    ?>
                </p>
                <p>
                    <span class="account-infor-title">Mật khẩu: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['password'].'</span>'; 
                    ?>        
                </p>
                <br>
                <p>
                    <span class="account-infor-title">Họ tên: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['fullname'].'</span>'; 
                    ?>
                </p>
                <p>
                    <span class="account-infor-title">Email: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['email'].'</span>'; 
                    ?>
                </p>
                <p>
                    <span class="account-infor-title">SĐT: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['sdt'].'</span>'; 
                    ?>
                </p>
                <p>
                    <span class="account-infor-title">Địa chỉ: </span>
                    <?php
                        echo'<span class="account-infor-content">'. $_SESSION['diachi'].'</span>'; 
                    ?>
                </p>
                <p>
                    <button class="account-infor-btn" onclick="changepassstart()" >Đổi mật khẩu</button>
                    <button class="account-infor-btn" onclick="changeinforstart()">Sửa thông tin</button>
                </p>
                <p>
                    <button type="" class="list-account-btn" id="view-list-btn" onclick="openviewbox('opentab','view-list-btn')">Xem ds tài khoản</button>
                    <button type="submit" class="logout" name="logout" onclick="logout()">Đăng xuất</button>
                </p>
                <div class="change-infor-form" id="change-infor-form" style="display: none;">  
                    <form action="" method="post">
                        <div class="fix-infor-form-item">
                            <span>Họ tên:</span>
                            <input type="text" name="fullname_user" id="" value="<?php echo $_SESSION['fullname'];?>">
                        </div>
                        <div class="fix-infor-form-item">
                            <span>Email:</span>
                            <input type="email" name="email_user" id="" value="<?php echo $_SESSION['email'];?>">
                        </div>
                        <div class="fix-infor-form-item">
                            <span>SĐT:</span>
                            <input type="text" name="sdt_user" id="" value="<?php echo $_SESSION['sdt'];?>">
                        </div>
                        <div class="fix-infor-form-item">
                            <span>Địa chỉ:</span>
                            <input type="text" name="diachi_user" id="" value="<?php echo $_SESSION['diachi'];?>">
                        </div>
                        <div class="fix-infor-form-item">
                            <button name="nochangeinfor" id="cancel-change" onclick="nochangeinfor()">Hủy</button>
                            <button name="saveinforchange"id="save-change"type="submit">Lưu</button>
                        </div>
                    </form>
                    <?php
                        if(isset($_POST['saveinforchange']))
                            require './xuly/xulysuathongtin.php'; 
                    ?>
                </div>
                <div class="change-infor-form" id="change-pass-form" style="display: none;">  
                    <form action="" method="post">
                        <div class="fix-pass-form-item">
                            <span>Mật khẩu cũ:</span><br>
                            <input type="password" name="old_pass" id="" value="">
                        </div>
                        <div class="fix-pass-form-item">
                            <span>Mật khẩu mới:</span><br>
                            <input type="password" name="new_pass" id="" value="">
                        </div>
                        <div class="fix-pass-form-item">
                            <span>Xác nhận mật khẩu mới:</span><br>
                            <input type="password" name="check_new_pass" id="" value="">
                        </div>
                        <div class="fix-pass-form-item">
                            <button name="nochangepass" id="cancel-change" onclick="nochangeinfor()">Hủy</button>
                            <button name="savepasswordchange" id="save-change" type="submit">Lưu</button>
                        </div>
                    </form>
                    <?php
                        if(isset($_POST['savepasswordchange']))
                            require './xuly/xulydoipass.php'; 
                    ?>
                </div>
            </div>
            <div class="account-infor-right" id="opentab" style="display: none;">
                <div class="account-infor-list-top">
                    <div class="account-infor-list-top-left">
                        <p class="right_top_left_title">Danh sách tài khoản</p>
                    </div>
                    <div class="account-infor-list-top-right">
                        <button class="add-new-account" onclick="document.location='ThemTaiKhoan.php'"><i class="fas fa-plus"></i>Thêm tài khoản</button>
                    </div>
                </div>
                <div class="account-infor-list-box">
                    <table>
                        <tr>
                            <th class="acc-col-1">Mã</th>
                            <th class="acc-col-2">Username</th>
                            <th class="acc-col-3">Role</th>
                            <th class="acc-col-4"></th>
                        </tr>
                        <?php require './xuly/xulyshowuser.php';  ?>
                        <!--<tr>
                            <td class="acc-col-1">TK001</td>
                            <td class="acc-col-2">Admin</td>
                            <td class="acc-col-3">Admin</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK002</td>
                            <td class="acc-col-2">Nguyenthuy</td>
                            <td class="acc-col-3">Nguyenthuy</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK003</td>
                            <td class="acc-col-2">Minhman</td>
                            <td class="acc-col-3">Minhman</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK004</td>
                            <td class="acc-col-2">Phuoctai</td>
                            <td class="acc-col-3">Phuoctai</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK005</td>
                            <td class="acc-col-2">Vanminh</td>
                            <td class="acc-col-3">Vanminh</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK002</td>
                            <td class="acc-col-2">Nguyenthuy</td>
                            <td class="acc-col-3">Nguyenthuy</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK003</td>
                            <td class="acc-col-2">Minhman</td>
                            <td class="acc-col-3">Minhman</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK004</td>
                            <td class="acc-col-2">Phuoctai</td>
                            <td class="acc-col-3">Phuoctai</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="acc-col-1">TK005</td>
                            <td class="acc-col-2">Vanminh</td>
                            <td class="acc-col-3">Vanminh</td>
                            <td class="acc-col-4">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
            </div>
        </div>
        <?php
            if($_SESSION['role'] == "guest")
            {
                ?>
                <script>
                    document.getElementById("view-list-btn").style.display = 'none';
                </script>
                <?php
            }
            else {
                ?>
                <script>
                    document.getElementById("view-list-btn").style.display = '';
                </script>
                <?php
            } 
        ?>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
<script type="text/javascript">
    function changeinforstart()
    {
        document.getElementById("change-infor-form").style.display ="";
        document.getElementById("change-pass-form").style.display ="none";
    }
    function changepassstart()
    {
        document.getElementById("change-pass-form").style.display ="";
        document.getElementById("change-infor-form").style.display ="none";
    }
    function nochangeinfor()
    {
        location.href = 'Hethong.php';
    }
    function logout()
    {
        location.href = 'logout.php';
    }
</script>
</html>