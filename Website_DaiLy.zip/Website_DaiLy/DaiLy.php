<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    $_SESSION['place'] = 'DL';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Daily.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Exportexcel.js"></script>
    <script src="./java/delitem.js"></script>
    <title>Đại Lý</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách đại lý</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" onclick="document.location='ThemDaiLy.php'"><i class="fas fa-plus"></i>Thêm đại lý</button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table', 'Danh Sách Đại Lý')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="filter-zone">
                    <form action="" method="post">
                        <input type="search" name="DLsearch" id="search-txt" placeholder="Nhập tên đại lý cần tìm">
                        <select name="Quanfilter" id="option-filter-zone">
                            <option value="0" selected id="option-first-line">Quận</option>
                            <option value="1">Quận 1</option>
                            <option value="2">Quận 2</option>
                            <option value="3">Quận 3</option>
                            <option value="4">Quận 4</option>
                            <option value="5">Quận 5</option>
                            <option value="6">Quận 6</option>
                            <option value="7">Quận 7</option>
                            <option value="8">Quận 8</option>
                            <option value="9">Quận 9</option>
                            <option value="10">Quận 10</option>
                            <option value="11">Quận 11</option>
                            <option value="12">Quận 12</option>
                            <option value="Bình Tân">Bình Tân</option>
                            <option value="Bình Thạnh">Bình Thạnh</option>
                            <option value="Gò Vấp">Gò Vấp</option>
                            <option value="Phú Nhuận">Phú Nhuận</option>
                            <option value="Tân Bình">Tân Bình</option>
                            <option value="Tân Phú">Tân Phú</option>
                            <option value="Thủ Đức">Thủ Đức</option>
                        </select>
                        <button name="submit" type="submit" class="search-item"><i class="fas fa-search"></i>Tìm kiếm</button>
                    </form>
                </div>
                <div class="excel-table-zone">
                    <table id="infor-table">
                        <tr>
                            <th class="daily-col-1">Mã đại lý</th>
                            <th class="daily-col-2">Tên đại lý</th>
                            <th class="daily-col-3">Điện thoại</th>
                            <th class="daily-col-4">Quận</th>
                            <th class="daily-col-5">Loại</th>
                            <th class="daily-col-6">Địa chỉ</th>
                            <th class="daily-col-7">Ngày tiếp nhận</th>
                            <th class="daily-col-8"></th>
                        </tr>
                        <?php 
                            if(isset($_POST['submit']))
                                require './xuly/xulytimkiem.php';
                            else 
                                require './xuly/xulyshowDL.php';  
                        ?>
                        <!--<tr>
                            <td class="daily-col-1">DL001</td>
                            <td class="daily-col-2">Đại lý ABC</td>
                            <td class="daily-col-3">0907123456</td>
                            <td class="daily-col-4">1</td>
                            <td class="daily-col-5">1</td>
                            <td class="daily-col-6">123 Bình Tiên, P.8, Q.1</td>
                            <td class="daily-col-7">19/01/2021</td>
                            <td class="daily-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="daily-col-1">DL002</td>
                            <td class="daily-col-2">Đại lý DEF</td>
                            <td class="daily-col-3">0907456123</td>
                            <td class="daily-col-4">4</td>
                            <td class="daily-col-5">2</td>
                            <td class="daily-col-6">456 Bình Thới, P.5, Q.4</td>
                            <td class="daily-col-7">20/02/2021</td>
                            <td class="daily-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="daily-col-1">DL001</td>
                            <td class="daily-col-2">Đại lý ABC</td>
                            <td class="daily-col-3">0907123456</td>
                            <td class="daily-col-4">1</td>
                            <td class="daily-col-5">1</td>
                            <td class="daily-col-6">123 Bình Tiên, P.8, Q.1</td>
                            <td class="daily-col-7">19/01/2021</td>
                            <td class="daily-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="daily-col-1">DL001</td>
                            <td class="daily-col-2">Đại lý ABC</td>
                            <td class="daily-col-3">0907123456</td>
                            <td class="daily-col-4">1</td>
                            <td class="daily-col-5">1</td>
                            <td class="daily-col-6">123 Bình Tiên, P.8, Q.1</td>
                            <td class="daily-col-7">19/01/2021</td>
                            <td class="daily-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="daily-col-1">DL001</td>
                            <td class="daily-col-2">Đại lý ABC</td>
                            <td class="daily-col-3">0907123456</td>
                            <td class="daily-col-4">1</td>
                            <td class="daily-col-5">1</td>
                            <td class="daily-col-6">123 Bình Tiên, P.8, Q.1</td>
                            <td class="daily-col-7">19/01/2021</td>
                            <td class="daily-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>