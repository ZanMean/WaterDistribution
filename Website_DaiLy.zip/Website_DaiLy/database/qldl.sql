-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th1 07, 2022 lúc 11:13 AM
-- Phiên bản máy phục vụ: 10.4.21-MariaDB
-- Phiên bản PHP: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `qldl`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chitietnhaphang`
--

CREATE TABLE `chitietnhaphang` (
  `PNH_id` int(11) NOT NULL,
  `Sp_id` int(11) NOT NULL,
  `DonviNH` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `SoluongNH` int(11) NOT NULL,
  `ThanhtienNH` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `chitietnhaphang`
--

INSERT INTO `chitietnhaphang` (`PNH_id`, `Sp_id`, `DonviNH`, `SoluongNH`, `ThanhtienNH`) VALUES
(1, 1, 'Thung', 4, 200000),
(1, 2, 'Loc', 3, 75000),
(2, 3, 'Thung', 2, 80000),
(3, 4, 'Ket', 30, 3000000),
(4, 1, 'Thung', 10, 1000000),
(4, 2, 'Loc', 3, 75000),
(4, 4, 'Ket', 5, 250000),
(5, 1, 'Thung', 10, 1000000),
(5, 2, 'Loc', 3, 75000),
(5, 4, 'Ket', 5, 250000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `chitietxuathang`
--

CREATE TABLE `chitietxuathang` (
  `PXH_id` int(11) NOT NULL,
  `Sp_id` int(11) NOT NULL,
  `DonviXH` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `SoluongXH` int(11) NOT NULL,
  `ThanhtienXH` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `chitietxuathang`
--

INSERT INTO `chitietxuathang` (`PXH_id`, `Sp_id`, `DonviXH`, `SoluongXH`, `ThanhtienXH`) VALUES
(1, 1, 'Loc', 1, 25000),
(1, 2, 'Thung', 1, 50000),
(1, 3, 'Loc', 1, 20000),
(2, 1, 'Ket', 2, 200000),
(2, 2, 'Loc', 4, 100000);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `congno`
--

CREATE TABLE `congno` (
  `CN_id` int(11) NOT NULL,
  `ThangCN` varchar(40) CHARACTER SET utf8mb4 NOT NULL,
  `Nodau_CN` float NOT NULL,
  `Phatsinh_CN` float NOT NULL,
  `Ngayghinhan_CN` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `Nocuoi_CN` float NOT NULL,
  `DL_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `congno`
--

INSERT INTO `congno` (`CN_id`, `ThangCN`, `Nodau_CN`, `Phatsinh_CN`, `Ngayghinhan_CN`, `Nocuoi_CN`, `DL_id`) VALUES
(2, '12', 0, 20000, '10/12/2021', 20000, 1),
(3, '12', 0, 10000, '10/12/2021', 10000, 2);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `daily`
--

CREATE TABLE `daily` (
  `DL_id` int(11) NOT NULL,
  `TenDL` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `LoaiDL` int(11) NOT NULL,
  `DiaChiDL` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `sdtDL` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `QuanDL` varchar(20) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `NgayTiepNhanDL` varchar(40) CHARACTER SET utf8 DEFAULT NULL,
  `EmailDL` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `daily`
--

INSERT INTO `daily` (`DL_id`, `TenDL`, `LoaiDL`, `DiaChiDL`, `sdtDL`, `QuanDL`, `NgayTiepNhanDL`, `EmailDL`) VALUES
(1, 'Đại lý ABC', 1, '148 Sư Vạn Hành, P10, Q6', '0909876543', '6', '19/12/2021', 'abccompany@gmail.com'),
(2, 'Đại lý DEF', 2, '311 Cao Văn Lầu, P13, Q9', '0909555555', '4', '30/11/2021', 'defcompany@gmail.com'),
(6, 'Đại lý vui', 1, '151 Phạm Phú Thứ, P13, Q2', '0909555555', '2', '06/12/2021', 'vuicompany@gmail.com'),
(8, 'Đại lý test', 1, '14A Cao Văn Lầu, P11, Q8', '0909666111', '8', '07/01/2022', 'testcompany@gmail.com');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phieunhaphang`
--

CREATE TABLE `phieunhaphang` (
  `PNH_id` int(11) NOT NULL,
  `TongtienPNH` float NOT NULL,
  `SotientraPNH` float NOT NULL,
  `ConlaiPNH` float NOT NULL,
  `NgaylapPNH` varchar(40) CHARACTER SET utf8mb4 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `phieunhaphang`
--

INSERT INTO `phieunhaphang` (`PNH_id`, `TongtienPNH`, `SotientraPNH`, `ConlaiPNH`, `NgaylapPNH`) VALUES
(1, 275000, 275000, 0, '20/12/2021'),
(2, 80000, 70000, 10000, '20/12/2021'),
(3, 3000000, 3000000, 0, '7/1/2022'),
(4, 1325000, 1325000, 0, '20/12/2021'),
(5, 1325000, 1325000, 0, '20/12/2021');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phieuthutien`
--

CREATE TABLE `phieuthutien` (
  `PTT_id` int(11) NOT NULL,
  `Ngaythutien` varchar(40) CHARACTER SET utf8mb4 NOT NULL,
  `Sotienthu_PTT` float NOT NULL,
  `DL_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `phieuthutien`
--

INSERT INTO `phieuthutien` (`PTT_id`, `Ngaythutien`, `Sotienthu_PTT`, `DL_id`) VALUES
(1, '16/12/2021', 10000, 1),
(3, '01/01/2022', 10000, 2),
(4, '01/01/2022', 5000, 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `phieuxuathang`
--

CREATE TABLE `phieuxuathang` (
  `PXH_id` int(11) NOT NULL,
  `TongtienPXH` float NOT NULL,
  `SotientraPXH` float NOT NULL,
  `ConlaiPXH` float NOT NULL,
  `NgaylapPXH` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `DL_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `phieuxuathang`
--

INSERT INTO `phieuxuathang` (`PXH_id`, `TongtienPXH`, `SotientraPXH`, `ConlaiPXH`, `NgaylapPXH`, `DL_id`) VALUES
(1, 95000, 90000, 5000, '14/12/2021', 1),
(2, 300000, 300000, 0, '15/12/2021', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `sanpham`
--

CREATE TABLE `sanpham` (
  `Sp_id` int(11) NOT NULL,
  `TenSP` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `GiaketSP` float NOT NULL,
  `GialocSP` float NOT NULL,
  `GiathungSP` float NOT NULL,
  `NSXSP` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL,
  `SoluongSP` int(11) NOT NULL,
  `Soluongton` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `sanpham`
--

INSERT INTO `sanpham` (`Sp_id`, `TenSP`, `GiaketSP`, `GialocSP`, `GiathungSP`, `NSXSP`, `SoluongSP`, `Soluongton`) VALUES
(1, 'Sting Hương Dâu', 50000, 25000, 100000, 'Sting', 1900, 1240),
(2, 'Coca Cà phê', 50000, 25000, 100000, 'Cocacola', 800, 518),
(3, 'Mountain Dew', 40000, 20000, 80000, 'Mountain Dew', 1000, 500),
(4, 'Cocacola', 50000, 25000, 100000, 'Cocacola', 2000, 90);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `username` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `pass` varchar(20) CHARACTER SET utf8mb4 NOT NULL,
  `fullname_user` varchar(255) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `email_user` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  `sdt_user` varchar(20) CHARACTER SET utf8mb4 DEFAULT NULL,
  `diachi_user` varchar(255) COLLATE utf8mb4_vietnamese_ci DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_vietnamese_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_vietnamese_ci;

--
-- Đang đổ dữ liệu cho bảng `user`
--

INSERT INTO `user` (`user_id`, `username`, `pass`, `fullname_user`, `email_user`, `sdt_user`, `diachi_user`, `role`) VALUES
(1, 'admin', 'admin', 'Yang Nguyên Thụy', 'rokota98@gmail.com', '0909123456', '113 Phạm Văn Chí p1, q6', 'admin'),
(3, 'phuoctai', 'phuoctai', 'Nguyễn Phước Tài', 'asai@gmail.com', '0909456123', '111 Tên Lửa , P.11, Q.Bình Tân ', 'guest'),
(4, 'minhman', 'minhman', NULL, NULL, NULL, NULL, 'guest');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `chitietnhaphang`
--
ALTER TABLE `chitietnhaphang`
  ADD KEY `PNH_id` (`PNH_id`),
  ADD KEY `Sp_id` (`Sp_id`);

--
-- Chỉ mục cho bảng `chitietxuathang`
--
ALTER TABLE `chitietxuathang`
  ADD KEY `PXH_id` (`PXH_id`),
  ADD KEY `Sp_id` (`Sp_id`);

--
-- Chỉ mục cho bảng `congno`
--
ALTER TABLE `congno`
  ADD PRIMARY KEY (`CN_id`),
  ADD KEY `DL_id` (`DL_id`);

--
-- Chỉ mục cho bảng `daily`
--
ALTER TABLE `daily`
  ADD PRIMARY KEY (`DL_id`);

--
-- Chỉ mục cho bảng `phieunhaphang`
--
ALTER TABLE `phieunhaphang`
  ADD PRIMARY KEY (`PNH_id`);

--
-- Chỉ mục cho bảng `phieuthutien`
--
ALTER TABLE `phieuthutien`
  ADD PRIMARY KEY (`PTT_id`),
  ADD KEY `DL_id` (`DL_id`);

--
-- Chỉ mục cho bảng `phieuxuathang`
--
ALTER TABLE `phieuxuathang`
  ADD PRIMARY KEY (`PXH_id`),
  ADD KEY `DL_id` (`DL_id`);

--
-- Chỉ mục cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  ADD PRIMARY KEY (`Sp_id`);

--
-- Chỉ mục cho bảng `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `congno`
--
ALTER TABLE `congno`
  MODIFY `CN_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT cho bảng `daily`
--
ALTER TABLE `daily`
  MODIFY `DL_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT cho bảng `phieunhaphang`
--
ALTER TABLE `phieunhaphang`
  MODIFY `PNH_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT cho bảng `phieuthutien`
--
ALTER TABLE `phieuthutien`
  MODIFY `PTT_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `phieuxuathang`
--
ALTER TABLE `phieuxuathang`
  MODIFY `PXH_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT cho bảng `sanpham`
--
ALTER TABLE `sanpham`
  MODIFY `Sp_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Các ràng buộc cho các bảng đã đổ
--

--
-- Các ràng buộc cho bảng `chitietnhaphang`
--
ALTER TABLE `chitietnhaphang`
  ADD CONSTRAINT `chitietnhaphang_ibfk_1` FOREIGN KEY (`PNH_id`) REFERENCES `phieunhaphang` (`PNH_id`),
  ADD CONSTRAINT `chitietnhaphang_ibfk_2` FOREIGN KEY (`Sp_id`) REFERENCES `sanpham` (`Sp_id`);

--
-- Các ràng buộc cho bảng `chitietxuathang`
--
ALTER TABLE `chitietxuathang`
  ADD CONSTRAINT `chitietxuathang_ibfk_1` FOREIGN KEY (`PXH_id`) REFERENCES `phieuxuathang` (`PXH_id`),
  ADD CONSTRAINT `chitietxuathang_ibfk_2` FOREIGN KEY (`Sp_id`) REFERENCES `sanpham` (`Sp_id`);

--
-- Các ràng buộc cho bảng `congno`
--
ALTER TABLE `congno`
  ADD CONSTRAINT `congno_ibfk_1` FOREIGN KEY (`DL_id`) REFERENCES `daily` (`DL_id`);

--
-- Các ràng buộc cho bảng `phieuthutien`
--
ALTER TABLE `phieuthutien`
  ADD CONSTRAINT `phieuthutien_ibfk_1` FOREIGN KEY (`DL_id`) REFERENCES `daily` (`DL_id`);

--
-- Các ràng buộc cho bảng `phieuxuathang`
--
ALTER TABLE `phieuxuathang`
  ADD CONSTRAINT `phieuxuathang_ibfk_1` FOREIGN KEY (`DL_id`) REFERENCES `daily` (`DL_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
