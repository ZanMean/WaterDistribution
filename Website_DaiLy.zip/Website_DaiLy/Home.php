<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    if($_SESSION['username'] == "")
    {
        ?>
        <script>
            document.location = "Login.php";
        </script>
        <?php
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./Js/switch.js"></script>
    <title>Trang Chủ</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item" href="Hethong.php">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="dashboard-content-container">
                <div class="dash-content-title">
                    <p>HOẠT ĐỘNG CÔNG TY</p>
                </div>
                <div class="dash-content-tongquat">
                    <div class="tongquat-item" id="tongquat-item1">
                        <div class="tongquat-item-left">
                            <i class="fas fa-wallet"></i>
                        </div>
                        <div class="tongquat-item-right">
                            <p>Số đại lý:</p>
                            <?php 
                                $DL_show_query = "select * from daily";
                                $DL_show_result = mysqli_query($con, $DL_show_query) or die(mysqli_error($con));
                                $rowcountDL = mysqli_num_rows($DL_show_result);
                            ?>
                            <p><?php echo $rowcountDL;?></p>
                        </div>
                    </div>
                    <div class="tongquat-item" id="tongquat-item2">
                        <div class="tongquat-item-left">
                            <i class="fas fa-shopping-cart"></i>
                        </div>
                        <div class="tongquat-item-right">
                            <p>Số Sản Phẩm:</p>
                            <?php 
                                $SP_show_query = "select * from `sanpham`";
                                $SP_show_result = mysqli_query($con, $SP_show_query) or die(mysqli_error($con));
                                $rowcountSP = mysqli_num_rows($SP_show_result);
                            ?>
                            <p><?php echo $rowcountSP;?></p>
                        </div>
                    </div>
                    <div class="tongquat-item" id="tongquat-item3">
                        <div class="tongquat-item-left">
                            <i class="fas fa-arrow-circle-left"></i>
                        </div>
                        <div class="tongquat-item-right">
                            <p>Số lần xuất hàng:</p>
                            <?php 
                                $PXH_show_query = "select * from phieuxuathang";
                                $PXH_show_result = mysqli_query($con, $PXH_show_query) or die(mysqli_error($con));
                                $rowcountPXH = mysqli_num_rows($PXH_show_result);
                            ?>
                            <p><?php echo $rowcountPXH;?></p>
                        </div>
                    </div>
                    <div class="tongquat-item" id="tongquat-item4">
                        <div class="tongquat-item-left">
                            <i class="fas fa-exclamation-triangle"></i>
                        </div>
                        <div class="tongquat-item-right">
                            <p>Số lần nhập hàng:</p>
                            <?php 
                                $PNH_show_query = "select * from phieunhaphang";
                                $PNH_show_result = mysqli_query($con, $PNH_show_query) or die(mysqli_error($con));
                                $rowcountPNH = mysqli_num_rows($PNH_show_result);
                            ?>
                            <p><?php echo $rowcountPNH;?></p>
                        </div>
                    </div>
                </div>
                <div class="dash-content-activity-table">
                    <div class="activity-table-zone">
                        <div class="activity-table-header">
                            <p>Đại lý</p>
                        </div>
                        <div class="activity-table-infor">
                            <div class="activity-table-infor-left">
                                <p>Số đại lý</p>
                                <p>Số sản phẩm</p>
                                <p>Số công nợ</p>
                                <p>Tổng tiền thu</p>
                            </div>
                            <div class="activity-table-infor-right">
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                            </div>
                        </div>
                    </div>
                    <div class="activity-table-zone">
                        <div class="activity-table-header">
                            <p>Thông tin kho</p>
                        </div>
                        <div class="activity-table-infor">
                            <div class="activity-table-infor-left">
                                <p>Số sản phẩm</p>
                                <p>Số phiếu xuất</p>
                                <p>Số phiếu nhập</p>
                                <p>Tổng hàng tồn</p>
                            </div>
                            <div class="activity-table-infor-right">
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                            </div>
                        </div>
                    </div>
                    <div class="activity-table-zone">
                        <div class="activity-table-header">
                            <p>Thông tin sản phẩm</p>
                        </div>
                        <div class="activity-table-infor">
                            <div class="activity-table-infor-left">
                                <p>Số sản phẩm</p>
                                <p>Tổng số lượng</p>
                                <p>Tổng giá trị</p>
                                <p>Tổng hàng tồn</p>
                            </div>
                            <div class="activity-table-infor-right">
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                                <p>0</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="dash-content-ranking">
                    <div class="ranking-table">
                        <table>
                            <tr class="ranking-title">
                                <th colspan="3">TOP ĐẠI LÝ</th>
                            </tr>
                            <tr class="col-title">
                              <th>Tên Đại Lý</th>
                              <th>Doanh Thu</th>
                              <th>Hạng</th>
                            </tr>
                            <tr>
                                <td>Đại Lý ABC</td>
                                <td>50.000</td>
                                <td>1</td>
                            </tr>
                            <tr>
                                <td>Đại Lý DEF</td>
                                <td>40.000</td>
                                <td>2</td>
                            </tr>
                            <tr>
                                <td>Đại Lý GHJ</td>
                                <td>20.000</td>
                                <td>3</td>
                            </tr>
                        </table>
                    </div>
                    <div class="ranking-table">
                        <table>
                            <tr class="ranking-title">
                                <th colspan="3">TOP SẢN PHẨM</th>
                            </tr>
                            <tr class="col-title">
                                <th>Tên Sản Phẩm</th>
                                <th>Số Lượng Tồn</th>
                                <th>Hạng</th>
                            </tr>
                            <tr>
                              <td>Pepsi</td>
                              <td>50</td>
                              <td>1</td>
                            </tr>
                            <tr>
                              <td>Mountain Dew</td>
                              <td>40</td>
                              <td>2</td>
                            </tr>
                            <tr>
                                <td>7 Up</td>
                                <td>20</td>
                                <td>3</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>