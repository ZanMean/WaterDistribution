<?php
    $con = ketnoi();
    $id=$_GET['id'];
    switch($_GET['place'])
    {
        case 'DL':
        {
            $sql="DELETE FROM daily WHERE DL_id=$id";
            $query= mysqli_query($con, $sql);
            header('location:../DaiLy.php');
            break;
        }
        case 'SP':
        {
            $sql="DELETE FROM sanpham WHERE Sp_id=$id";
            $query= mysqli_query($con, $sql);
            header('location:../Sanpham.php');
            break;
        }
        case 'ACC':
        {
            $sql="DELETE FROM user WHERE user_id=$id";
            $query= mysqli_query($con, $sql);
            header('location:../Hethong.php');
            break;
        }
        case 'CN':
            {
                $sql="DELETE FROM congno WHERE 	CN_id=$id";
                $query= mysqli_query($con, $sql);
                header('location:../CongNo.php');
                break;
            }
    }
?>