<?php
  include '../connectdb/connect.php';
  if (isset($_GET['layout'])) 
  {
      switch ($_GET['layout']) 
      {
        case 'xoa':
          require_once 'xoa.php';
          break;
        case 'sua':
          require_once '../giaodien/sua.php';
          break;
      }
  }
?>

