<?php
    $TenDL=mysqli_real_escape_string($con,$_POST['TenDL']);
    $NgaylapPXH = date("d/m/Y");
    $TongtienPXH = mysqli_real_escape_string($con,$_POST['TongtienPXH']);
    $SotientraPXH = mysqli_real_escape_string($con,$_POST['SotientraPXH']);
    $ConlaiPXH = mysqli_real_escape_string($con,$_POST['ConlaiPXH']);
    $KT_DL_query = "SELECT * FROM daily WHERE TenDL='$TenDL'";
    $KT_DL_result = mysqli_query($con,$KT_DL_query) or die(mysqli_error($con));
    $rows_fetched=mysqli_num_rows($KT_DL_result);
    if($rows_fetched == "" || $TenDL == "")
    {
        ?>
        <script>
            alert("Tên đại lý không hợp lệ vui lòng làm lại từ đầu;")
            location.href = 'Kho.php';
        </script>
        <?php
    }
    else
    {
        $row = mysqli_fetch_assoc($KT_DL_result);
        $DL_id = $row["DL_id"];
        $add_PXH_query ="INSERT INTO phieuxuathang(TongtienPXH,SotientraPXH,ConlaiPXH,NgaylapPXH,DL_id) VALUES('$TongtienPXH','$SotientraPXH','$ConlaiPXH','$NgaylapPXH','$DL_id')";
        $add_PXH_result = mysqli_query($con,$add_PXH_query) or die(mysqli_error($con));
        $findPXH_id_query = "SELECT max(PXH_id) FROM phieuxuathang";
        $findPXH_id_result = mysqli_query($con,$findPXH_id_query) or die(mysqli_error($con));
        $row = mysqli_fetch_assoc($findPXH_id_result);
        $PXH_id = $row["max(PXH_id)"];
        $tmp = 0;
        for ($i = 0 ; $i < count($_POST['spname']); $i++)
        {
            $x = $_POST['spname'][$tmp];
            $y = $_POST['dv_choice'][$tmp];
            $t = $_POST['soluong_choice'][$tmp];
            $z = $_POST['thanhtiensp'][$tmp];
            $find_matchsp_query = "SELECT * FROM sanpham WHERE TenSP='$x'";
            $find_matchsp_result = mysqli_query($con,$find_matchsp_query) or die(mysqli_error($con));
            $resultrow = mysqli_fetch_assoc($find_matchsp_result);
            $Sp_id = $resultrow["Sp_id"];
            $Soluongton = $resultrow["Soluongton"];
            $addchitiet_XH_query = "INSERT INTO chitietxuathang(PXH_id,Sp_id,DonviXH,SoluongXH,ThanhtienXH) VALUES('$PXH_id','$Sp_id','$y','$t','$z')";
            $addchitiet_XH_result = mysqli_query($con,$addchitiet_XH_query) or die(mysqli_error($con));
            if($y == "Thung")
            {
                $Soluongtonmoi = $Soluongton - ($t*24);
            }
            else if ($y == "Ket")
            {
                $Soluongtonmoi = $Soluongton - ($t*12);
            }
            else 
            {
                $Soluongtonmoi = $Soluongton - ($t*6);
            }
            $update_tonkho_query = "UPDATE sanpham SET Soluongton='$Soluongtonmoi' WHERE Sp_id='$Sp_id'";
            $update_tonkho_result = mysqli_query($con,$update_tonkho_query) or die(mysqli_error($con));
            $tmp++;
        }
        ?>
        <script>
            alert("Lập phiếu xuất hàng thành công");
            location.href = 'Kho.php';
        </script>
        <?php
    }
?>