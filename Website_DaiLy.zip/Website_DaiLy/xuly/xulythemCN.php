<?php
    $con = ketnoi();
    $TenDL=mysqli_real_escape_string($con,$_POST['TenDL']);
    $ThangCN=mysqli_real_escape_string($con,$_POST['ThangCN']);
    $Nodau_CN=mysqli_real_escape_string($con,$_POST['Nodau_CN']);
    $Phatsinh_CN=mysqli_real_escape_string($con,$_POST['Phatsinh_CN']);
    $Nocuoi_CN=mysqli_real_escape_string($con,$_POST['Nocuoi_CN']);
    $Ngayghinhan_CN = date("d/m/Y");
    $findmatch_DL_query="select DL_id from `daily` where TenDL='$TenDL'";
    $findmatch_DL_result=mysqli_query($con,$findmatch_DL_query) or die(mysqli_error($con));
    $rows_fetched=mysqli_num_rows($findmatch_DL_result);
    if($rows_fetched <= 0)
    {
        ?>
        <script>
            alert("Không tìm thấy đại lý");
        </script>
        <?php
    }
    else 
    {
        $row= mysqli_fetch_assoc($findmatch_DL_result);
        $match_DL_id = $row["DL_id"];
        echo $match_DL_id;
        $CN_registration_query="insert into congno(ThangCN,Nodau_CN,Phatsinh_CN,Ngayghinhan_CN,Nocuoi_CN,DL_id) values ('$ThangCN','$Nodau_CN','$Phatsinh_CN','$Ngayghinhan_CN','$Nocuoi_CN','$match_DL_id')";
        $CN_registration_result=mysqli_query($con,$CN_registration_query) or die(mysqli_error($con));
        ?>
        <script>
            alert("Thêm thành công!");
        </script>
        <meta http-equiv="refresh" content="3;url=./CongNo.php"/>
        <?php
    }
?>