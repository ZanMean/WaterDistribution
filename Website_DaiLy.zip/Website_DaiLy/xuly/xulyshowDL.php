<?php
    $DL_show_query = "select * from `daily`";
    $DL_show_result = mysqli_query($con, $DL_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($DL_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($DL_show_result))
        {
            ?>
            <tr>
                <td class="daily-col-1"><?php echo $row["DL_id"]; ?></td>
                <td class="daily-col-2"><?php echo $row["TenDL"]; ?></td>
                <td class="daily-col-3"><?php echo $row["sdtDL"]; ?></td>
                <td class="daily-col-4"><?php echo $row["QuanDL"]; ?></td>
                <td class="daily-col-5"><?php echo $row["LoaiDL"]; ?></td>
                <td class="daily-col-6"><?php echo $row["DiaChiDL"]; ?></td>
                <td class="daily-col-7"><?php echo $row["NgayTiepNhanDL"]; ?></td>
                <td class="daily-col-8">
                    <!--<button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>-->
                    <a class="fix-btn" href="ChitietDL.php?id=<?php echo $row['DL_id']; ?>">Xem</a>
                    <a class="del-btn" onclick="return Del('<?php echo $row['TenDL']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['DL_id']; ?>&place=DL">Xóa</a>
                </td>
            </tr>
            <?php
        }
    }
?>