<?php
    $PXH_show_query = "SELECT * FROM phieuxuathang, daily WHERE phieuxuathang.DL_id = daily.DL_id;";
    $PXH_show_result = mysqli_query($con, $PXH_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($PXH_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($PXH_show_result))
        {
            ?>
            <tr>
                <td class="pxh-col-1"><?php echo $row["PXH_id"]; ?></td>
                <td class="pxh-col-2"><?php echo $row["TenDL"]; ?></td>
                <td class="pxh-col-3"><?php echo $row["TongtienPXH"]; ?></td>
                <td class="pxh-col-4"><?php echo $row["SotientraPXH"]; ?></td>
                <td class="pxh-col-5"><?php echo $row["ConlaiPXH"]; ?></td>
                <td class="pxh-col-6"><?php echo $row["NgaylapPXH"]; ?></td>
                <td class="pxh-col-7">
                    <a class="fix-btn" href="ChitietPXH.php?id=<?php echo $row['PXH_id'];?>">Xem</a>
                </td>
            </tr>
            <?php
        }
    }
?>