<?php
    $SP_show_query = "select * from `sanpham`";
    $SP_show_result = mysqli_query($con, $SP_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($SP_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($SP_show_result))
        {
            ?>
            <tr>
                <td class="checkbox-col"><input type="checkbox" name="selectitem[]" class="select-check" id="select-check" value="<?php echo $row["Sp_id"]; ?>" onclick="check()"></td>
                <td class="stor-col-1"><?php echo $row["Sp_id"]; ?></td>
                <td class="stor-col-2"><?php echo $row["TenSP"]; ?></td>
                <td class="stor-col-3"><?php echo $row["GiaketSP"]; ?></td>
                <td class="stor-col-4"><?php echo $row["GialocSP"]; ?></td>
                <td class="stor-col-5"><?php echo $row["GiathungSP"]; ?></td>
                <td class="stor-col-6"><?php echo $row["NSXSP"]; ?></td>
                <td class="stor-col-7"><?php echo $row["Soluongton"]; ?></td>
                <td class="stor-col-8">
                    <a class="fix-btn" href="ChitietSPKho.php?id=<?php echo $row["Sp_id"]; ?>">Xem</a>
                </td>
            </tr>
            <?php
        }
    }
?>