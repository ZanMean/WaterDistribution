<?php
    $fullname_user=mysqli_real_escape_string($con,$_POST['fullname_user']);
    $email_user=mysqli_real_escape_string($con,$_POST['email_user']);
    $sdt_user=mysqli_real_escape_string($con,$_POST['sdt_user']);
    $diachi_user=mysqli_real_escape_string($con,$_POST['diachi_user']);
    $username = $_SESSION['username'];
    $change_infor_user_query = "UPDATE user SET fullname_user='$fullname_user' , email_user='$email_user' , sdt_user='$sdt_user' ,  diachi_user='$diachi_user' WHERE username = '$username'";
    $change_infor_user_result = mysqli_query($con,$change_infor_user_query) or die(mysqli_error($con));
    $_SESSION['fullname'] = $fullname_user;
    $_SESSION['email'] = $email_user;
    $_SESSION['sdt'] = $sdt_user;
    $_SESSION['diachi'] = $diachi_user;
    ?>
    <script>
        location.href = 'Hethong.php';
    </script>
    <?php
?>