<?php
    $old_pass=mysqli_real_escape_string($con,$_POST['old_pass']);
    $new_pass=mysqli_real_escape_string($con,$_POST['new_pass']);
    $check_new_pass=mysqli_real_escape_string($con,$_POST['check_new_pass']);
    $username = $_SESSION['username'];
    $validate_PW_query = "SELECT * FROM user WHERE username='$username' AND pass='$old_pass'";
    $validate_PW_result = mysqli_query($con,$validate_PW_query) or die(mysqli_error($con));
    $rows_fetched=mysqli_num_rows($validate_PW_result);
    if($rows_fetched == 0)
    {
        ?>
        <script>
            alert("Mật khẩu cũ nhập chưa đúng");
        </script>
        <?php
    }
    else
    {
        if($check_new_pass != $new_pass)
        {
            ?>
            <script>
                alert("Mật khẩu nhập lại không chính xác");
            </script>
            <?php
        }
        else 
        {
            $change_pass_user_query = "UPDATE user SET pass='$new_pass' WHERE username = '$username'";
            $change_pass_user_result = mysqli_query($con,$change_pass_user_query) or die(mysqli_error($con));
            $_SESSION['password'] = $new_pass;
            ?>
            <script>
                location.href = 'Hethong.php';
            </script>
            <?php
        } 
    }
?>