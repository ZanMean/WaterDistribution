<?php
    $TenSP=mysqli_real_escape_string($con,$_POST['TenSP']);
    $NSXSP=mysqli_real_escape_string($con,$_POST['NSXSP']);
    $SoluongSP=mysqli_real_escape_string($con,$_POST['SoluongSP']);
    $GiaketSP=mysqli_real_escape_string($con,$_POST['GiaketSP']);
    $GialocSP=mysqli_real_escape_string($con,$_POST['GialocSP']);
    $GiathungSP=mysqli_real_escape_string($con,$_POST['GiathungSP']);
    $DL_update_query="update sanpham set TenSP='$TenSP' , NSXSP='$NSXSP' , SoluongSP='$SoluongSP' , GiaketSP='$GiaketSP', GialocSP='$GialocSP' , GiathungSP='$GiathungSP' where Sp_id='$id'";
    $DL_update_result=mysqli_query($con,$DL_update_query) or die(mysqli_error($con));
    ?>
    <script>
        alert("Sửa thành công!");
    </script>
    <meta http-equiv="refresh" content="3;url=./ChitietSP.php?id=<?php echo $_GET['id'];?>"/>