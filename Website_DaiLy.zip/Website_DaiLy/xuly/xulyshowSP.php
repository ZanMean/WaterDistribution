<?php
    $SP_show_query = "select * from `sanpham`";
    $SP_show_result = mysqli_query($con, $SP_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($SP_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($SP_show_result))
        {
            ?>
            <tr>
                <td class="pro-col-1"><?php echo $row["Sp_id"]; ?></td>
                <td class="pro-col-2"><?php echo $row["TenSP"]; ?></td>
                <td class="pro-col-3"><?php echo $row["GiaketSP"]; ?></td>
                <td class="pro-col-4"><?php echo $row["GialocSP"]; ?></td>
                <td class="pro-col-5"><?php echo $row["GiathungSP"]; ?></td>
                <td class="pro-col-6"><?php echo $row["NSXSP"]; ?></td>
                <td class="pro-col-7"><?php echo $row["SoluongSP"]; ?></td>
                <td class="pro-col-8">
                    <a class="fix-btn" href="ChitietSP.php?id=<?php echo $row["Sp_id"]; ?>">Xem</a>
                    <a class="del-btn" onclick="return Del('<?php echo $row['TenSP']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['Sp_id']; ?>&place=SP">Xóa</a>
                </td>
            </tr>
            <?php
        }
    }
?>