<?php
    /*require '../connectdb/connect.php';
    session_start();*/
    /*$name= mysqli_real_escape_string($con,$_POST['name']);*/
    $con = ketnoi();
    $TenDL=mysqli_real_escape_string($con,$_POST['TenDL']);
    $sdtDL=mysqli_real_escape_string($con,$_POST['sdtDL']);
    $QuanDL=mysqli_real_escape_string($con,$_POST['QuanDL']);
    $LoaiDL=mysqli_real_escape_string($con,$_POST['LoaiDL']);
    $DiaChiDL=mysqli_real_escape_string($con,$_POST['DiaChiDL']);
    $EmailDL=mysqli_real_escape_string($con,$_POST['EmailDL']);
    $NgayTiepNhanDL=date("d/m/Y");
    if($TenDL == "") {
        ?>
        <script>
            alert("Tên đại lý không được để trống");
        </script>
        <?php
    }
    $duplicate_DL_query="select * from `daily` where TenDL='$TenDL'";
    $duplicate_DL_result=mysqli_query($con,$duplicate_DL_query) or die(mysqli_error($con));
    $rows_fetched=mysqli_num_rows($duplicate_DL_result);
    if($rows_fetched>0){
        ?>
        <script>
            alert("Đại lý này đã tồn tại!");
        </script>
        <?php
    } else {
        if ($LoaiDL != 1 AND $LoaiDL != 2)
        {
            ?>
            <script>
                alert("Loại đại lý phải là 1 hoặc 2");
            </script>
            <?php
        }
        else
        {
            $DL_registration_query="insert into daily(TenDL,sdtDL,QuanDL,LoaiDL,DiaChiDL,NgayTiepNhanDL) values ('$TenDL','$sdtDL','$QuanDL','$LoaiDL','$DiaChiDL','$NgayTiepNhanDL')";
            $DL_registration_result=mysqli_query($con,$DL_registration_query) or die(mysqli_error($con));
            ?>
            <script>
                alert("Thêm thành công!");
            </script>
            <meta http-equiv="refresh" content="3;url=./DaiLy.php"/>
            <?php
        }
    }
?> 