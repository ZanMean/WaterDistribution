<?php 
    $con = ketnoi();
    switch($_SESSION['place'])
    {
        case 'DL':
        {
            $DLsearch = mysqli_real_escape_string($con,$_POST['DLsearch']);
            $DL_search_query="select * from `daily` where TenDL='$DLsearch'";
            $DL_search_result = mysqli_query($con, $DL_search_query) or die(mysqli_error($con));
            $rowcount = mysqli_num_rows($DL_search_result);
            if($DLsearch != null) 
            {
                if($rowcount > 0)
                {
                    //output data 
                    while($row= mysqli_fetch_assoc($DL_search_result))
                    {
                        ?>
                            <tr>
                            <td class="daily-col-1"><?php echo $row["DL_id"]; ?></td>
                            <td class="daily-col-2"><?php echo $row["TenDL"]; ?></td>
                            <td class="daily-col-3"><?php echo $row["sdtDL"]; ?></td>
                            <td class="daily-col-4"><?php echo $row["QuanDL"]; ?></td>
                            <td class="daily-col-5"><?php echo $row["LoaiDL"]; ?></td>
                            <td class="daily-col-6"><?php echo $row["DiaChiDL"]; ?></td>
                            <td class="daily-col-7"><?php echo $row["NgayTiepNhanDL"]; ?></td>
                            <td class="daily-col-8">
                                <a class="fix-btn" href="ChitietDL.php?id=<?php echo $row['DL_id']; ?>">Xem</a>
                                <a class="del-btn" onclick="return Del('<?php echo $row['TenDL']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['DL_id']; ?>&place=DL">Xóa</a>
                            </td>
                            </tr>
                        <?php
                    }
                }
                else
                {
                    echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                    require './xuly/xulyshowDL.php'; 
                }
            }
            else
            {
                $Quanfilter = mysqli_real_escape_string($con,$_POST['Quanfilter']);
                $Quan_filter_query="select * from `daily` where QuanDL='$Quanfilter'";
                $Quan_filter_result = mysqli_query($con, $Quan_filter_query) or die(mysqli_error($con));
                $filterrowcount = mysqli_num_rows($Quan_filter_result);
                if($Quanfilter != "0") 
                {
                    if($filterrowcount > 0)
                    {
                        //output data 
                        while($row= mysqli_fetch_assoc($Quan_filter_result))
                        echo '<tr><td class="daily-col-1">'.$row["DL_id"].'</td><td class="daily-col-2">'.$row["TenDL"].'</td><td class="daily-col-3">'.$row["sdtDL"].'</td><td class="daily-col-4">'.$row["QuanDL"].'</td><td class="daily-col-5">'.$row["LoaiDL"].'</td><td class="daily-col-6">'.$row["DiaChiDL"].'</td><td class="daily-col-7">'.$row["NgayTiepNhanDL"].'</td><td class="daily-col-8"><button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button><button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button><button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button></td></tr>';
                    }
                    else
                    {
                        echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                        require './xuly/xulyshowDL.php'; 
                    }
                }
                else
                {
                    require './xuly/xulyshowDL.php'; 
                }
            }
            break;
        }
        case 'CN':
        {
            $DLsearch = mysqli_real_escape_string($con,$_POST['DLsearch']);
            $DL_search_query="select * from `daily` where TenDL='$DLsearch'";
            $DL_search_result = mysqli_query($con, $DL_search_query) or die(mysqli_error($con));
            $Find = mysqli_fetch_assoc($DL_search_result);
            $GetDL_id = $Find['DL_id'];
            $GetName = $Find['TenDL'];
            $CN_search_query="select * from `congno` where DL_id='$GetDL_id'";
            $CN_search_result = mysqli_query($con, $CN_search_query) or die(mysqli_error($con));
            $rowcount = mysqli_num_rows($CN_search_result);
            if($DLsearch != null) 
            {
                if($rowcount > 0)
                {
                    //output data 
                    while($row= mysqli_fetch_assoc($CN_search_result))
                    {
                        ?>
                            <tr>
                                <td class="CN-col-1"><?php echo $row["ThangCN"]; ?></td>
                                <td class="CN-col-2"><?php echo $GetName; ?></td>
                                <td class="CN-col-3"><?php echo $row["Nodau_CN"]; ?></td>
                                <td class="CN-col-4"><?php echo $row["Phatsinh_CN"]; ?></td>
                                <td class="CN-col-5"><?php echo $row["Ngayghinhan_CN"]; ?></td>
                                <td class="CN-col-6"><?php echo $row["Nocuoi_CN"]; ?></td>
                                <td class="CN-col-7">
                                    <a class="fix-btn" href="ChitietCN.php?id=<?php echo $row['CN_id'];?>">Xem</a>
                                    <!-- <a class="del-btn" onclick="return Del('<?php echo 'Công nợ '.$row['TenDL']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['CN_id']; ?>&place=CN">Xóa</a> -->
                                    <a class="del-btn">Xóa</a>
                                </td>
                            </tr>
                        <?php
                    }
                }
                else
                {
                    echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                    require './xuly/xulyshowCN.php'; 
                }
            }
            else
            {
                $Thangfilter = mysqli_real_escape_string($con,$_POST['Thangfilter']);
                $Thang_filter_query="select * from `congno` where ThangCN='$Thangfilter'";
                $Thang_filter_result = mysqli_query($con, $Thang_filter_query) or die(mysqli_error($con));
                $filterrowcount = mysqli_num_rows($Thang_filter_result);
                if($Thangfilter != "0") 
                {
                    if($filterrowcount > 0)
                    {
                        //output data 
                        while($row= mysqli_fetch_assoc($Thang_filter_result))
                        {
                            $GetDL_id = $row["DL_id"];
                            $DL_search_query="select * from `daily` where DL_id='$GetDL_id'";
                            $DL_search_result = mysqli_query($con, $DL_search_query) or die(mysqli_error($con));
                            $Find = mysqli_fetch_assoc($DL_search_result);
                            $GetName = $Find['TenDL'];
                            ?>
                            <tr>
                                <td class="CN-col-1"><?php echo $row["ThangCN"]; ?></td>
                                <td class="CN-col-2"><?php echo $GetName; ?></td>
                                <td class="CN-col-3"><?php echo $row["Nodau_CN"]; ?></td>
                                <td class="CN-col-4"><?php echo $row["Phatsinh_CN"]; ?></td>
                                <td class="CN-col-5"><?php echo $row["Ngayghinhan_CN"]; ?></td>
                                <td class="CN-col-6"><?php echo $row["Nocuoi_CN"]; ?></td>
                                <td class="CN-col-7">
                                    <a class="fix-btn" href="ChitietCN.php?id=<?php echo $row['CN_id'];?>">Xem</a>
                                    <!-- <a class="del-btn" onclick="return Del('<?php echo 'Công nợ '.$row['TenDL']; ?>')" href=
                                    "./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['CN_id']; ?>&place=CN"
                                    >Xóa</a> -->
                                    <a class="del-btn">Xóa</a>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                    else
                    {
                        echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                        require './xuly/xulyshowCN.php'; 
                    }
                }
                else
                {
                    require './xuly/xulyshowCN.php'; 
                }
            }
            break;
        }
        case 'SP':
        {
            $SPsearch = mysqli_real_escape_string($con,$_POST['SPsearch']);
            $SP_search_query="select * from `sanpham` where TenSP='$SPsearch'";
            $SP_search_result = mysqli_query($con, $SP_search_query) or die(mysqli_error($con));
            $rowcount = mysqli_num_rows($SP_search_result);
            if($SPsearch != null) 
            {
                if($rowcount > 0)
                {
                    //output data 
                    while($row= mysqli_fetch_assoc($SP_search_result))
                    {
                        ?>
                        <tr>
                            <td class="pro-col-1"><?php echo $row["Sp_id"]; ?></td>
                            <td class="pro-col-2"><?php echo $row["TenSP"]; ?></td>
                            <td class="pro-col-3"><?php echo $row["GiaketSP"]; ?></td>
                            <td class="pro-col-4"><?php echo $row["GialocSP"]; ?></td>
                            <td class="pro-col-5"><?php echo $row["GiathungSP"]; ?></td>
                            <td class="pro-col-6"><?php echo $row["NSXSP"]; ?></td>
                            <td class="pro-col-7"><?php echo $row["SoluongSP"]; ?></td>
                            <td class="pro-col-8">
                                <a class="fix-btn" href="ChitietSP.php?id=<?php echo $row["Sp_id"]; ?>">Xem</a>
                                <a class="del-btn" onclick="return Del('<?php echo $row['TenSP']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['Sp_id']; ?>&place=SP">Xóa</a>
                            </td>
                        </tr>
                        <?php
                    }
                }
                else
                {
                    echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                    require './xuly/xulyshowSP.php'; 
                }
            }
            else
            {
                require './xuly/xulyshowSP.php'; 
            }
            break; 
        }
        case 'KHO':
        {
            $SPsearch = mysqli_real_escape_string($con,$_POST['SPsearch']);
            $SP_search_query="select * from `sanpham` where TenSP='$SPsearch'";
            $SP_search_result = mysqli_query($con, $SP_search_query) or die(mysqli_error($con));
            $rowcount = mysqli_num_rows($SP_search_result);
            if($SPsearch != null) 
            {
                if($rowcount > 0)
                {
                    //output data 
                    while($row= mysqli_fetch_assoc($SP_search_result))
                    {
                        ?>
                        <tr>
                            <td class="checkbox-col"><input type="checkbox" name="selectitem[]" class="select-check" id="select-check" value="<?php echo $row["Sp_id"]; ?>" onclick="check()"></td>
                            <td class="stor-col-1"><?php echo $row["Sp_id"]; ?></td>
                            <td class="stor-col-2"><?php echo $row["TenSP"]; ?></td>
                            <td class="stor-col-3"><?php echo $row["GiaketSP"]; ?></td>
                            <td class="stor-col-4"><?php echo $row["GialocSP"]; ?></td>
                            <td class="stor-col-5"><?php echo $row["GiathungSP"]; ?></td>
                            <td class="stor-col-6"><?php echo $row["NSXSP"]; ?></td>
                            <td class="stor-col-7"><?php echo $row["Soluongton"]; ?></td>
                            <td class="stor-col-8">
                                <a class="fix-btn" href="ChitietSPKho.php?id=<?php echo $row["Sp_id"]; ?>">Xem</a>
                            </td>
                        </tr>
                        <?php
                    }
                }
                else
                {
                    echo'<p class="errorfindtxt">(*) không tồn tại</p>';
                    require './xuly/xulyshowkho.php'; 
                }
            }
            else
            {
                require './xuly/xulyshowkho.php'; 
            }
            break; 
        }
    }
?>
