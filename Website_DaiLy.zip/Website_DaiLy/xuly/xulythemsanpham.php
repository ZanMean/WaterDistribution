<?php
    /*require '../connectdb/connect.php';
    session_start();*/
    /*$name= mysqli_real_escape_string($con,$_POST['name']);*/
    $con = ketnoi();
    $TenSP=mysqli_real_escape_string($con,$_POST['TenSP']);
    $GiaketSP=mysqli_real_escape_string($con,$_POST['GiaketSP']);
    $GialocSP=mysqli_real_escape_string($con,$_POST['GialocSP']);
    $GiathungSP=mysqli_real_escape_string($con,$_POST['GiathungSP']);
    $NSXSP=mysqli_real_escape_string($con,$_POST['NSXSP']);
    $SoluongSP=mysqli_real_escape_string($con,$_POST['SoluongSP']);
    if($TenSP == "") {
        ?>
        <script>
            alert("Tên sản phẩm không được để trống");
        </script>
        <?php
    }
    else 
    {
    $duplicate_DL_query="select * from `sanpham` where TenSP='$TenSP'";
    $duplicate_DL_result=mysqli_query($con,$duplicate_DL_query) or die(mysqli_error($con));
    $rows_fetched=mysqli_num_rows($duplicate_DL_result);
    if($rows_fetched>0){
        ?>
        <script>
            alert("Sản phẩm này đã tồn tại!");
        </script>
        <?php
    } else {
        ?>
        <?php
            $SP_registration_query="insert into sanpham(TenSP,GiaketSP,GialocSP,GiathungSP,NSXSP,SoluongSP,Soluongton) values ('$TenSP','$GiaketSP','$GialocSP','$GiathungSP','$NSXSP','$SoluongSP','0')";
            $SP_registration_result=mysqli_query($con,$SP_registration_query) or die(mysqli_error($con));
        ?>
        <script>
            alert("Thêm thành công!");
            location.href = 'SanPham.php';
        </script>     
        <?php
        }      
    }
?> 