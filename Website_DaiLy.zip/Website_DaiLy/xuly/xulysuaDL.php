<?php
    /*require '../connectdb/connect.php';
    session_start();*/
    /*$name= mysqli_real_escape_string($con,$_POST['name']);*/
    $con = ketnoi();
    $TenDL=mysqli_real_escape_string($con,$_POST['TenDL']);
    $sdtDL=mysqli_real_escape_string($con,$_POST['sdtDL']);
    $QuanDL=mysqli_real_escape_string($con,$_POST['QuanDL']);
    $LoaiDL=mysqli_real_escape_string($con,$_POST['LoaiDL']);
    $DiaChiDL=mysqli_real_escape_string($con,$_POST['DiaChiDL']);
    $NgayTiepNhanDL=mysqli_real_escape_string($con,$_POST['NgayTiepNhanDL']);
    $DL_update_query="update daily set TenDL='$TenDL' , sdtDL='$sdtDL' , QuanDL='$QuanDL' , LoaiDL='$LoaiDL', DiaChiDL='$DiaChiDL' , NgayTiepNhanDL='$NgayTiepNhanDL' where DL_id='$id'";
    $DL_update_result=mysqli_query($con,$DL_update_query) or die(mysqli_error($con));
    ?>
    <script>
        alert("Sửa thành công!");
    </script>
    <meta http-equiv="refresh" content="3;url=./ChitietDL.php?id=<?php echo $_GET['id'];?>"/>