<?php
    $NgaylapPNH =mysqli_real_escape_string($con,$_POST['NgaylapPNH']);
    $TongtienPNH = mysqli_real_escape_string($con,$_POST['TongtienPNH']);
    $SotientraPNH = mysqli_real_escape_string($con,$_POST['SotientraPNH']);
    $ConlaiPNH = mysqli_real_escape_string($con,$_POST['ConlaiPNH']);
    $add_PNH_query ="INSERT INTO phieunhaphang(TongtienPNH,SotientraPNH,ConlaiPNH,NgaylapPNH) VALUES('$TongtienPNH','$SotientraPNH','$ConlaiPNH','$NgaylapPNH')";
    $add_PNH_result = mysqli_query($con,$add_PNH_query) or die(mysqli_error($con));
    $findPNH_id_query = "SELECT max(PNH_id) FROM phieunhaphang";
    $findPNH_id_result = mysqli_query($con,$findPNH_id_query) or die(mysqli_error($con));
    $row = mysqli_fetch_assoc($findPNH_id_result);
    $PNH_id = $row["max(PNH_id)"];
    $tmp = 0;
    for ($i = 0 ; $i < count($_POST['spname']); $i++)
    {
        $x = $_POST['spname'][$tmp];
        $y = $_POST['dv_choice'][$tmp];
        $t = $_POST['soluong_choice'][$tmp];
        $z = $_POST['thanhtiensp'][$tmp];
        $find_matchsp_query = "SELECT * FROM sanpham WHERE TenSP='$x'";
        $find_matchsp_result = mysqli_query($con,$find_matchsp_query) or die(mysqli_error($con));
        $resultrow = mysqli_fetch_assoc($find_matchsp_result);
        $Sp_id = $resultrow["Sp_id"];
        $Soluongton = $resultrow["Soluongton"];
        $addchitiet_NH_query = "INSERT INTO chitietnhaphang(PNH_id,Sp_id,DonviNH,SoluongNH,ThanhtienNH) VALUES('$PNH_id','$Sp_id','$y','$t','$z')";
        $addchitiet_NH_result = mysqli_query($con,$addchitiet_NH_query) or die(mysqli_error($con));
        if($y == "Thung")
        {
            $Soluongtonmoi = $Soluongton + ($t*24);
        }
        else if ($y == "Ket")
        {
            $Soluongtonmoi = $Soluongton + ($t*12);
        }
        else 
        {
            $Soluongtonmoi = $Soluongton + ($t*6);
        }
        $update_tonkho_query = "UPDATE sanpham SET Soluongton='$Soluongtonmoi' WHERE Sp_id='$Sp_id'";
        $update_tonkho_result = mysqli_query($con,$update_tonkho_query) or die(mysqli_error($con));
        $tmp++;
    }
    ?>
        <script>
            alert("Lập phiếu nhập hàng thành công");
            location.href = 'Kho.php';
        </script>