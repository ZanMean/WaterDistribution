<?php
    $CN_show_query = "select * from `congno`,`daily` where congno.DL_id=daily.DL_id";
    $CN_show_result = mysqli_query($con, $CN_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($CN_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($CN_show_result))
        {
            ?>
            <tr>
                <td class="CN-col-1"><?php echo $row["ThangCN"]; ?></td>
                <td class="CN-col-2"><?php echo $row["TenDL"]; ?></td>
                <td class="CN-col-3"><?php echo $row["Nodau_CN"]; ?></td>
                <td class="CN-col-4"><?php echo $row["Phatsinh_CN"]; ?></td>
                <td class="CN-col-5"><?php echo $row["Ngayghinhan_CN"]; ?></td>
                <td class="CN-col-6"><?php echo $row["Nocuoi_CN"]; ?></td>
                <td class="CN-col-7">
                    <a class="fix-btn" href="ChitietCN.php?id=<?php echo $row['CN_id'];?>">Xem</a>
                    <a class="del-btn" onclick="return Del('<?php echo 'Công nợ '.$row['TenDL']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['CN_id']; ?>&place=CN">Xóa</a>
                </td>
            </tr>
            <?php
        }
    }
?>