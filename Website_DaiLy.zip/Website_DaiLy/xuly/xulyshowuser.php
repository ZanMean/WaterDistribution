<?php
    $user_show_query = "select * from `user`";
    $user_show_result = mysqli_query($con, $user_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($user_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($user_show_result))
        {
            ?>
            <tr>
                <td class="acc-col-1"><?php echo $row["user_id"] ?></td>
                <td class="acc-col-2"><?php echo $row["username"] ?></td>
                <td class="acc-col-3"><?php echo $row["role"] ?></td>
                <td class="acc-col-4">
                    <a class="del-btn" onclick="return Del('<?php echo $row['username']; ?>')" href="./chuyentiep/chuyentiep.php?layout=xoa&id=<?php echo $row['user_id']; ?>&place=ACC">Xóa</a>
                </td>
            </tr>
            <?php 
        }
    }
?>