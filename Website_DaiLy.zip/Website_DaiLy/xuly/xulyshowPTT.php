<?php
    $PTT_show_query = "SELECT * FROM phieuthutien, daily WHERE phieuthutien.DL_id=daily.DL_id";
    $PTT_show_result = mysqli_query($con, $PTT_show_query) or die(mysqli_error($con));
    $rowcount = mysqli_num_rows($PTT_show_result);
    if($rowcount > 0)
    {
        //output data 
        while($row= mysqli_fetch_assoc($PTT_show_result))
        {
            ?>
            <tr>
                <td class="pht-col-1"><?php echo $row["Ngaythutien"]; ?></td>
                <td class="pht-col-2"><?php echo $row["TenDL"]; ?></td>
                <td class="pht-col-3"><?php echo $row["DiaChiDL"]; ?></td>
                <td class="pht-col-4"><?php echo $row["sdtDL"]; ?></td>
                <td class="pht-col-5"><?php echo $row["EmailDL"]; ?></td>
                <td class="pht-col-6"><?php echo $row["Sotienthu_PTT"]; ?></td>
                <td class="pht-col-7">
                    <a class="fix-btn" href="ChitietPTT.php?id=<?php echo $row['PTT_id'];?>">Xem</a>
                </td>
            </tr>
            <?php
        }
    }
?>