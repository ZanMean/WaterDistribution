<?php
                                        if (isset($_POST['submit'])) {
                                           
                                            $check = 0;
                                            $username = mysqli_real_escape_string($con, $_POST['username']);
                                            $password = mysqli_real_escape_string($con,$_POST['password']);
                                            if($check == 0){
                                                $user_authentication_query = "select * from `user` where username='$username' and pass='$password'";
                                                $user_authentication_result = mysqli_query($con, $user_authentication_query) or die(mysqli_error($con));
                                                $rows_fetched = mysqli_num_rows($user_authentication_result);
                                                if($rows_fetched==0){
                                                    echo "<p class=\"error\">Sai email hoặc mật khẩu</p><br>";
                                                }
                                                else{
                                                    $row= mysqli_fetch_assoc($user_authentication_result);
                                                    if($row['role'] == 'admin'){
                                                        $_SESSION['username'] = $username;
                                                        $_SESSION['password'] = $password;
                                                        $_SESSION['id'] = $row['user_id'];
                                                        $_SESSION['role'] = $row['role'];
                                                        $_SESSION['fullname'] = $row['fullname_user'];
                                                        $_SESSION['email'] = $row['email_user'];
                                                        $_SESSION['sdt'] = $row['sdt_user'];
                                                        $_SESSION['diachi'] = $row['diachi_user'];
                                                        header('location:Home.php');
                                                    }
                                                    else{
                                                        $_SESSION['username']=$username;
                                                        $_SESSION['password'] = $password;
                                                        $_SESSION['id']=$row['user_id'];
                                                        $_SESSION['role'] = $row['role'];//user id
                                                        $_SESSION['fullname'] = $row['fullname_user'];
                                                        $_SESSION['email'] = $row['email_user'];
                                                        $_SESSION['sdt'] = $row['sdt_user'];
                                                        $_SESSION['diachi'] = $row['diachi_user'];
                                                        header('location:Home.php');
                                                    }
                                                }
                                            }
                                        }
                                     ?>
