<?php
    $stt = 1;
    $moneystack = 0;
    foreach($_POST['selectitem'] as $check) 
    {
        $sql_find = "SELECT * FROM sanpham WHERE Sp_id=$check";
        $find_result = mysqli_query($con, $sql_find) or die(mysqli_error($con));
        while($row= mysqli_fetch_assoc($find_result))
        {
            ?>
            <tr>
                <td class="xuat-col-1"><?php echo $stt?></td>
                <td class="xuat-col-2"><input type="hidden" name="spname[]" value="<?php echo $row["TenSP"]; ?>"><?php echo $row["TenSP"]; ?></td>
                <td class="xuat-col-3">
                    <select name="dv_choice[]" class="dv_choice" id="<?php echo $check?>" onchange="checkobjectdv(this.id)">
                        <option style="display: none;"></option>
                        <option value="Ket">Két</option>
                        <option value="Loc">Lốc</option>
                        <option value="Thung">Thùng</option>
                    </select>
                </td>
                <td class="xuat-col-4">
                    <input type="number" value="1" min="1" name="soluong_choice[]" id="soluong<?php echo $check?>" onchange="checkobjectsl(this.id)"> 
                </td>
                <td class="xuat-col-5" id="dongia<?php echo $check?>"></td>
                <td class="xuat-col-6" id="thanhtien<?php echo $check?>"></td>
                <input type="hidden" name="thanhtiensp[]" id="thanhtiensp<?php echo $check?>" value="">
            </tr>       
            <?php
            $stt++;
        }
    }
?>