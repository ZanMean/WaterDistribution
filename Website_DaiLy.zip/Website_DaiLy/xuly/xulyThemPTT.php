<?php
    $TenDL=mysqli_real_escape_string($con,$_POST['TenDL']);
    $Sotienthu_PTT = mysqli_real_escape_string($con,$_POST['Sotienthu_PTT']);
    if($TenDL == "")
    {
        ?>
        <script>
            alert("Tên đại lý không được để trống");
        </script>
        <?php
    }
    else 
    {
        $find_DL_query = "SELECT * FROM daily WHERE TenDL='$TenDL'";
        $find_DL_result = mysqli_query($con,$find_DL_query) or die(mysqli_error($con));
        $row= mysqli_fetch_assoc($find_DL_result);
        $DL_id = $row['DL_id'];
        $findnewest_Nocuoi_query = "SELECT max(CN_id) FROM congno WHERE DL_id='$DL_id'";
        $findnewest_Nocuoi_result = mysqli_query($con,$findnewest_Nocuoi_query) or die(mysqli_error($con));
        $row= mysqli_fetch_assoc($findnewest_Nocuoi_result); 
        $NewestCN_id = $row['max(CN_id)'];
        $findDL_Nocuoi_query = "SELECT Nocuoi_CN FROM congno WHERE CN_id='$NewestCN_id'";
        $findDL_Nocuoi_result = mysqli_query($con,$findDL_Nocuoi_query) or die(mysqli_error($con));
        $row= mysqli_fetch_assoc($findDL_Nocuoi_result); 
        $Nocuoi_CN = $row['Nocuoi_CN'];
        if($Sotienthu_PTT > $Nocuoi_CN)
        {
            ?>
            <script>
                alert("Số tiền thu nhiều hơn nợ đại lý");
            </script>
            <?php
        }
        else
        {
            $Ngaythutien = date("d/m/Y");
            $create_PTT_query = "INSERT INTO phieuthutien(Ngaythutien,Sotienthu_PTT,DL_id) VALUES('$Ngaythutien','$Sotienthu_PTT','$DL_id')";
            $create_PTT_result = mysqli_query($con,$create_PTT_query) or die(mysqli_error($con));
            ?>
            <script>
                alert("Thêm phiếu thu tiền thành công");
                document.location="CongNo.php"
            </script>
            <?php
        }
    }
?>