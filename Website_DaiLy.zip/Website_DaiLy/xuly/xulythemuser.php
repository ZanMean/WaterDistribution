<?php
    /*require '../connectdb/connect.php';
    session_start();*/
    /*$name= mysqli_real_escape_string($con,$_POST['name']);*/
    $con = ketnoi();
    $username=mysqli_real_escape_string($con,$_POST['username']);
    $pass=mysqli_real_escape_string($con,$_POST['pass']);
    $role=mysqli_real_escape_string($con,$_POST['role']);
    if($username == "")
    {
        ?>
        <script>
            alert("Tên người dùng không được để trống");
        </script>
        <?php
    }
    else
    {
        $duplicate_user_query="select * from `user` where username='$username'";
        $duplicate_user_result=mysqli_query($con,$duplicate_user_query) or die(mysqli_error($con));
        $rows_fetched=mysqli_num_rows($duplicate_user_result);
        if($rows_fetched>0){
            ?>
            <script>
                alert("Người dùng này đã tồn tại!");
            </script>
            <?php
        } else {
            ?>
            <?php
                $user_registration_query="insert into user(username,pass,role) values ('$username','$pass','$role')";
                $user_registration_result=mysqli_query($con,$user_registration_query) or die(mysqli_error($con));
            ?>
            <script>
                alert("Thêm thành công!");
            </script>
            <meta http-equiv="refresh" content="3;url=./Hethong.php"/>
            
            <?php
        }
    }
?> 