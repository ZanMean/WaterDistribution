<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Themsp.css"/>
    <link rel="stylesheet" href="./design/Lapphieu.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./java/Switch.js"></script>
    <title>Nhập hàng</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title"></p>
                </div>
                <div class="body_right_top_right">
                    <button class="return-btn" onclick="document.location='Kho.php'"><i class="fas fa-times"></i>Hủy</button>
                    <button name="XNNH" type="submit" form="NH_form" class="save-btn"><i class="fas fa-save"></i>Tạo</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="add-new-item-box">
                    <div class="item-box-title">
                        <p>PHIẾU NHẬP HÀNG</p>
                    </div>
                    <div class="box-form-XH-content">
                        <form id="NH_form" action="" method="post">
                            <div class="item-group-container-top">
                                <div class="item-group-XH">
                                    <label class="item-name">Ngày nhập hàng:</label><br>
                                    <input type="text" name="NgaylapPNH" id="" class="itemXH-text-box">
                                </div>
                            </div>
                            <div class="item-group-container-body">
                                <table class="out-table">
                                    <tr>
                                        <th class="xuat-col-1">STT</th>
                                        <th class="xuat-col-2">Mặt hàng</th>
                                        <th class="xuat-col-3">Đơn vị tính</th>
                                        <th class="xuat-col-4">Số lượng</th>
                                        <th class="xuat-col-5">Đơn giá</th>
                                        <th class="xuat-col-6">Thành tiền</th>
                                    </tr>
                                    <?php require './xuly/xulyshowNHList.php';  ?>
                                </table>
                            </div>
                            <div class="item-group-container-bottom">
                                <div class="item-group-XH-bottom">
                                    <label class="item-name">Tổng tiền:</label>
                                    <span id="count-total"></span>
                                    <input id="totalvar" type="hidden" name="TongtienPNH">
                                </div>
                                <div class="item-group-XH-bottom">
                                    <label class="item-name">Số tiền trả:</label>
                                    <input type="text" name="SotientraPNH" id="tientra" class="XHPay-text-box" onchange="conlai()">
                                </div>
                                <div class="item-group-XH-bottom">
                                    <label class="item-name">Còn lại:</label>
                                    <span id="conlai"></span>
                                    <input id="conlaivar" type="hidden" name="ConlaiPNH">
                                </div>
                            </div>
                        </form>
                        <?php
                            if(isset($_POST['XNNH']))
                                require './xuly/xulyNH.php'; 
                            else if (isset($_POST['reset']))
                                header('location:Kho.php');
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
<script type="text/javascript">
    function checkobjectdv (objectid) 
    {
        /*var tmp = document.getElementsByClassName("dv_choice")[0].innerHTML;*/
        var idsoluong = "soluong" + objectid;
        var soluongdachon = document.getElementById(idsoluong).value;
        var dvdachon = document.getElementById(objectid).value;
        const dv = ["Ket","Loc","Thung"];
        for(var i = 0; i < dv.length ; i++ )
        {
            if(dvdachon == dv[i])
            {
                guiajax(dvdachon,objectid,soluongdachon);
            } 
        }
    }
    function checkobjectsl(objectid) 
    {
        var newid = objectid.slice(7,8);
        checkobjectdv(newid);
    }
    function conlai()
    {
        var con = 0;
        var sotientra = document.getElementById("tientra").value;
        con = parseFloat(document.getElementById("count-total").innerHTML) - sotientra;
        document.getElementById("conlai").innerHTML = con;
        document.getElementById("conlaivar").value = con;
    }
    function guiajax(dvdachon,objectid,soluongdachon) 
    {
        var total = 0;
        $.ajax ({
            method: 'post',
            url: './model/PXH_model.php',
            datatype: "JSON",
            data: {donvi: dvdachon, sanpham: objectid, soluong: soluongdachon},
            success: function(response) 
            {
                var data = $.parseJSON(response);
                var iddongia = "dongia" + objectid;
                var idthanhtien = "thanhtien" + objectid;
                var idthanhtiensp = "thanhtiensp" + objectid;
                document.getElementById(iddongia).innerHTML = data[0];
                document.getElementById(idthanhtien).innerHTML = data[1];
                document.getElementById(idthanhtiensp).value = data[1];
                var x = document.getElementsByClassName("xuat-col-6");
                for (var i = 1; i < x.length ; i ++)
                {
                    if(x[i].innerHTML != "") 
                    {
                        total += parseFloat(x[i].innerHTML);
                    }
                }
                document.getElementById("count-total").innerHTML = total;
                document.getElementById("totalvar").value = total;
                document.getElementById("tientra").value = 0;
                document.getElementById("conlai").innerHTML = total;
            }
        });
    }
    /*$(document).ready(function(){

    });*/
</script>
</html>