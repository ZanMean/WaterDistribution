<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Themsp.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Switch.js"></script>
    <script src="./java/Submitgiantiep.js"></script>
    <title>Công Nợ</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <form action="" method="post" id="ThemSP-form">
            <div class="body_right">
                <div class="body_right_top">
                    <div class="body_right_top_left">
                        <p class="right_top_left_title"></p>
                    </div>
                    <div class="body_right_top_right" id="right-1"> 
                        <button class="return-btn" id="return" name="reset" type="reset" onclick="document.location='CongNo.php'">Quay về</button>
                    </div>
                </div>
                <div class="body_right_bottom">
                    <div class="add-new-item-box">
                        <div class="item-box-title">
                            <p>THÔNG TIN</p>
                        </div>
                        <div class="box-form-content">
                            <?php
                                $id=$_GET['id']; 
                                $CTCN_show_query = "select * from congno where CN_id=$id";
                                $CTCN_show_result = mysqli_query($con, $CTCN_show_query) or die(mysqli_error($con));
                                while($row= mysqli_fetch_assoc($CTCN_show_result))
                                {
                                    $DL_id = $row['DL_id'];
                                    $find_DL_query = "select * from daily where DL_id = '$DL_id'";
                                    $find_DL_result = mysqli_query($con, $find_DL_query) or die(mysqli_error($con));
                                    $row2 = mysqli_fetch_assoc($find_DL_result);
                                    $TenDL = $row2['TenDL'];
                                   ?>
                                    <div class="item-group-container-left">
                                        <div class="item-group">
                                            <label class="item-name">Tháng:</label><br>
                                            <input type="text" name="ThangCN" id="" class="item-text-box" value="<?php echo $row["ThangCN"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Tên đại lý:</label><br>
                                            <input type="text" name="TenDL" id="" class="item-text-box" value="<?php echo $TenDL; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Ngày ghi nhận:</label><br>
                                            <input type="text" name="TenDL" id="" class="item-text-box" value="<?php echo $row["Ngayghinhan_CN"]; ?>" disabled>
                                        </div>
                                    </div>
                                    <div class="item-group-container-right">
                                        <div class="item-group">
                                            <label class="item-name">Nợ đầu:</label><br>
                                            <input type="text" name="Nodau_CN" id="" class="item-text-box" value="<?php echo $row["Nodau_CN"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Nợ phát sinh:</label><br>
                                            <input type="text" name="Phatsinh_CN" id="" class="item-text-box" value="<?php echo $row["Phatsinh_CN"]; ?>" disabled>
                                        </div>
                                        <div class="item-group">
                                            <label class="item-name">Nợ cuối:</label><br>
                                            <input type="text" name="Nocuoi_CN" id="" class="item-text-box" value="<?php echo $row["Nocuoi_CN"]; ?>" disabled>
                                        </div>
                                    </div>
                                    <?php
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>