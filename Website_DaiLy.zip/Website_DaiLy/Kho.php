<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    $_SESSION['place'] = 'KHO';
?>
<script>
    console.log('<?php echo $_SESSION['place']; ?>')
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/CongNo.css"/>
    <link rel="stylesheet" href="./design/Kho.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Exportexcel.js"></script>
    <script src="./java/Switch.js"></script>
    <script src="./java//checkselect.js"></script>
    <title>Kho</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right" id="show-tab">
            <div class="body_right_top" >
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách sản phẩm tồn kho</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" style="width: 120px;" onclick="opentab('show-tab','hidden-tab')">Xem ds phiếu xuất</button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table-1', 'Danh Sách Sản Phẩm Kho')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="filter-zone">
                    <form action="" method="post">
                        <input type="search" name="SPsearch" id="search-txt" placeholder="Nhập tên sản phẩm cần tìm">
                        <button name="submit" type="submit" class="search-item"><i class="fas fa-search"></i>Tìm kiếm</button>
                    </form>
                </div>
                <div class="excel-table-zone">
                    <form action="" method="post">
                        <table id="infor-table-1">
                            <tr>
                                <th class="checkbox-col"></th>
                                <th class="stor-col-1">Mã sản phẩm</th>
                                <th class="stor-col-2">Tên sản phẩm</th>
                                <th class="stor-col-3">Giá/Két</th>
                                <th class="stor-col-4">Giá/Lốc</th>
                                <th class="stor-col-5">Giá/Thùng</th>
                                <th class="stor-col-6">Nhà sản xuất</th>
                                <th class="stor-col-7">Số lượng</th>
                                <th class="stor-col-8"></th>
                            </tr>
                            <?php 
                                if(isset($_POST['submit']))
                                    require './xuly/xulytimkiem.php';
                                else 
                                    require './xuly/xulyshowkho.php';  
                            ?>
                        </table>
                    </div>
                    <div class="nhap-xuat-btn-zone">
                        <button class="nhap-hang" name="NH" id="btn-nhap-hang" onclick="javascript: form.action='LapPhieuNH.php';" disabled>Lập phiếu nhập hàng</button>
                        <button class="xuat-hang" name="XH" onclick="javascript: form.action='LapPhieuXH.php';" id="btn-xuat-hang" disabled>Lập phiếu xuất hàng</button>
                    </div>
                </form>
            </div>
        </div> 
        <div class="body_right" id="hidden-tab" style="display: none;">
            <div class="body_right_top" >
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách phiếu xuất hàng</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" style="width: 120px;" onclick="opentab('hidden-tab','show-tab')">Xem ds sản phẩm</button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table-2', 'Danh Sách Phiếu Xuất Hàng')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="excel-table-zone">
                    <table id="infor-table-2">
                        <tr>
                            <th class="pxh-col-1">Mã phiếu</th>
                            <th class="pxh-col-2">Tên đại lý</th>
                            <th class="pxh-col-3">Tổng tiền</th>
                            <th class="pxh-col-4">Số tiền trả</th>
                            <th class="pxh-col-5">Còn lại</th>
                            <th class="pxh-col-6">Ngày lập phiếu</th>
                            <th class="pxh-col-7"></th>
                        </tr>
                        <?php require './xuly/xulyshowPXH.php'; ?>
                        <!--<tr>
                            <td class="pxh-col-1">PX001</td>
                            <td class="pxh-col-2">Đại lý ABC</td>
                            <td class="pxh-col-3">100.000</td>
                            <td class="pxh-col-4">75.000</td>
                            <td class="pxh-col-5">25.000</td>
                            <td class="pxh-col-6">23/11/2021</td>
                            <td class="pxh-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Xem chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pxh-col-1">PX002</td>
                            <td class="pxh-col-2">Đại lý DEF</td>
                            <td class="pxh-col-3">80.000</td>
                            <td class="pxh-col-4">70.000</td>
                            <td class="pxh-col-5">10.000</td>
                            <td class="pxh-col-6">24/11/2021</td>
                            <td class="pxh-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Xem chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pxh-col-1">PX003</td>
                            <td class="pxh-col-2">Đại lý DEF</td>
                            <td class="pxh-col-3">80.000</td>
                            <td class="pxh-col-4">70.000</td>
                            <td class="pxh-col-5">10.000</td>
                            <td class="pxh-col-6">24/11/2021</td>
                            <td class="pxh-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Xem chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
<script>

</script>
<!--<script type="text/javascript">
    $(document).ready(function() 
    {
        function themphieuXH()
        {
            const remember = [];
            var btnvalue = document.getElementById("select-check").value;
        }
    })
</script>-->
</html>