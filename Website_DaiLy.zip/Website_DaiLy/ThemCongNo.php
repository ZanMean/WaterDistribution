<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/Themsp.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Switch.js"></script>
    <title>Công Nợ</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <form action="" method="post" id="ThemCN-form">
            <div class="body_right">
                <div class="body_right_top">
                    <div class="body_right_top_left">
                        <p class="right_top_left_title"></p>
                    </div>
                    <div class="body_right_top_right">
                        <button class="return-btn" name="reset" onclick="document.location='CongNo.php'"><i class="fas fa-times"></i>Hủy</button>
                        <button class="save-btn" name="submit"><i class="fas fa-save"></i>Thêm</button>
                    </div>
                </div>
                <div class="body_right_bottom">
                    <div class="add-new-item-box">
                        <div class="item-box-title">
                            <p>THÔNG TIN</p>
                        </div>
                        <div class="box-form-content">
                            <div class="item-group-container-left">
                                <div class="item-group">
                                    <label class="item-name">Tháng:</label><br>
                                    <input type="text" name="ThangCN" id="" class="item-text-box">
                                </div>
                                <div class="item-group">
                                    <label class="item-name">Tên đại lý:</label><br>
                                    <input type="text" name="TenDL" id="" class="item-text-box">
                                </div>
                            </div>
                            <div class="item-group-container-right">
                                <div class="item-group">
                                    <label class="item-name">Nợ đầu:</label><br>
                                    <input type="text" name="Nodau_CN" id="" class="item-text-box">
                                </div>
                                <div class="item-group">
                                    <label class="item-name">Nợ phát sinh:</label><br>
                                    <input type="text" name="Phatsinh_CN" id="" class="item-text-box">
                                </div>
                                <div class="item-group">
                                    <label class="item-name">Nợ cuối:</label><br>
                                    <input type="text" name="Nocuoi_CN" id="" class="item-text-box">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
    <?php 
        if(isset($_POST['submit']))
            require './xuly/xulythemCN.php'; 
        else if (isset($_POST['reset'])) 
        {
            ?>
            <script>
                document.location='CongNo.php';
            </script> 
            <?php
        }
    ?>
</body>
</html>