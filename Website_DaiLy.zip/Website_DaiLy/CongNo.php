<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    $_SESSION['place'] = 'CN';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <link rel="stylesheet" href="./design/CongNo.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./java/Exportexcel.js"></script>
    <script src="./java/Switch.js"></script>
    <script src="./java/delitem.js"></script>
    <title>Công Nợ</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right" id="show-tab">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách công nợ</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" onclick="opentab('show-tab','hidden-tab')">Xem phiếu thu</button>
                    <button class="add-new-item" onclick="document.location='ThemCongNo.php'"><i class="fas fa-plus"></i>Thêm công nợ</button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table', 'Danh Sách Công Nợ')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="filter-zone">
                    <form action="" method="post">
                        <input type="search" name="DLsearch" id="search-txt" placeholder="Nhập tên đại lý">
                        <select name="Thangfilter" id="option-filter-zone">
                            <option value="0" selected disabled id="option-first-line">Tháng</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="5">5</option>
                            <option value="6">6</option>
                            <option value="7">7</option>
                            <option value="8">8</option>
                            <option value="9">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                        </select>
                    <button name="submit" type="submit" class="search-item"><i class="fas fa-search"></i>Tìm kiếm</button>
                    </form>
                </div>
                <div class="excel-table-zone">
                    <table id="infor-table">
                        <tr>
                            <th class="CN-col-1">Tháng</th>
                            <th class="CN-col-2">Tên đại lý</th>
                            <th class="CN-col-3">Nợ đầu</th>
                            <th class="CN-col-4">Phát sinh</th>
                            <th class="CN-col-5">Ngày ghi nhận</th>
                            <th class="CN-col-6">Nợ cuối</th>
                            <th class="CN-col-7"></th>
                        </tr>
                        <?php 
                            if(isset($_POST['submit']))
                                require './xuly/xulytimkiem.php';
                            else 
                                require './xuly/xulyshowCN.php';  
                        ?>
                        <!--<tr>
                            <td class="CN-col-1">11</td>
                            <td class="CN-col-2">Đại lý ABC</td>
                            <td class="CN-col-3">0</td>
                            <td class="CN-col-4">15000</td>
                            <td class="CN-col-5">15000</td>
                            <td class="CN-col-6">21/11/2021</td>
                            <td class="CN-col-7">0</td>
                            <td class="CN-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="CN-col-1">11</td>
                            <td class="CN-col-2">Đại lý DEF</td>
                            <td class="CN-col-3">0</td>
                            <td class="CN-col-4">20000</td>
                            <td class="CN-col-5">15000</td>
                            <td class="CN-col-6">21/11/2021</td>
                            <td class="CN-col-7">5000</td>
                            <td class="CN-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="CN-col-1">11</td>
                            <td class="CN-col-2">Đại lý ABC</td>
                            <td class="CN-col-3">0</td>
                            <td class="CN-col-4">15000</td>
                            <td class="CN-col-5">15000</td>
                            <td class="CN-col-6">21/11/2021</td>
                            <td class="CN-col-7">0</td>
                            <td class="CN-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="CN-col-1">11</td>
                            <td class="CN-col-2">Đại lý DEF</td>
                            <td class="CN-col-3">0</td>
                            <td class="CN-col-4">20000</td>
                            <td class="CN-col-5">15000</td>
                            <td class="CN-col-6">21/11/2021</td>
                            <td class="CN-col-7">5000</td>
                            <td class="CN-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="CN-col-1">11</td>
                            <td class="CN-col-2">Đại lý ABC</td>
                            <td class="CN-col-3">0</td>
                            <td class="CN-col-4">15000</td>
                            <td class="CN-col-5">15000</td>
                            <td class="CN-col-6">21/11/2021</td>
                            <td class="CN-col-7">0</td>
                            <td class="CN-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
            </div>
        </div>
        <div class="body_right" id="hidden-tab" style="display:none;">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách phiếu thu tiền</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" onclick="opentab('hidden-tab','show-tab')">Xem công nợ</button>
                    <button class="add-new-item" onclick="document.location='ThemPhieuThu.php'"><i class="fas fa-plus"></i>Thêm phiếu thu</button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table-1', 'Danh Sách Phiếu Thu')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="filter-zone">
                </div>
                <div class="excel-table-zone">
                    <table id="infor-table">
                        <tr>
                            <th class="Pht-col-1">Ngày thu tiền</th>
                            <th class="Pht-col-2">Tên đại lý</th>
                            <th class="Pht-col-3">Địa chỉ</th>
                            <th class="Pht-col-4">Điện thoại</th>
                            <th class="Pht-col-5">Email</th>
                            <th class="Pht-col-6">Số tiền thu</th>
                            <th class="Pht-col-7"></th>
                        </tr>
                        <?php require './xuly/xulyshowPTT.php';?>
                        <!--<tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý ABC</td>
                            <td class="Pht-col-3">123 Bình Tiên, P.8, Q.1</td>
                            <td class="Pht-col-4">0907123456</td>
                            <td class="Pht-col-5">abccompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý DEF</td>
                            <td class="Pht-col-3">456 Bình Thới, P.5, Q.4</td>
                            <td class="Pht-col-4">0907456123</td>
                            <td class="Pht-col-5">defcompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý ABC</td>
                            <td class="Pht-col-3">123 Bình Tiên, P.8, Q.1</td>
                            <td class="Pht-col-4">0907123456</td>
                            <td class="Pht-col-5">abccompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý DEF</td>
                            <td class="Pht-col-3">456 Bình Thới, P.5, Q.4</td>
                            <td class="Pht-col-4">0907456123</td>
                            <td class="Pht-col-5">defcompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý ABC</td>
                            <td class="Pht-col-3">123 Bình Tiên, P.8, Q.1</td>
                            <td class="Pht-col-4">0907123456</td>
                            <td class="Pht-col-5">abccompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="Pht-col-1">23/11/2021</td>
                            <td class="Pht-col-2">Đại lý DEF</td>
                            <td class="Pht-col-3">456 Bình Thới, P.5, Q.4</td>
                            <td class="Pht-col-4">0907456123</td>
                            <td class="Pht-col-5">defcompany@gmail.com</td>
                            <td class="Pht-col-6">150000</td>
                            <td class="Pht-col-7">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Chi tiết"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>