<?php
    require './connectdb/connect.php';
    $con = ketnoi();
    session_start();
    $_SESSION['place'] = 'SP';
?>
<script>
    console.log('<?php echo $_SESSION['place']; ?>')
</script>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./design/Homepage.css"/>
    <link rel="stylesheet" href="./design/AwesomeFontStyle.css"/>
    <link rel="stylesheet" href="./design/Product.css"/>
    <script src="https://use.fontawesome.com/releases/v5.15.1/js/all.js"></script>
    <script src="./java/Exportexcel.js"></script>
    <script src="./java/delitem.js"></script>
    <title>Sản Phẩm</title>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <ul class="left-title">
                <li class="title-item"><a class="tab-title">Administrator</a></li>
            </ul>
        </div>
        <div class="header-right">
            <?php 
                echo'<a id="right-item">'. $_SESSION['username'].'</a>';
            ?>
        </div>
    </div>
    <div class="body">
        <div class="body_left">
            <ul class="main_menu">
                <li class="main_menu_item"><a href="Home.php" class="menu_link">TRANG CHỦ</a></li>
                <li class="main_menu_item"><a href="DaiLy.php" class="menu_link">ĐẠI LÝ</a></li>
                <li class="main_menu_item" id="sp_item"><a href="SanPham.php" class="menu_link">SẢN PHẨM</a></li>
                <li class="main_menu_item"><a href="CongNo.php" class="menu_link">CÔNG NỢ - THU CHI</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Kho.php" class="menu_link">KHO</a></li>
                <li class="main_menu_item" id="sp_item"><a href="Hethong.php" class="menu_link">HỆ THỐNG</a></li>
            </ul>
        </div>
        <div class="body_right">
            <div class="body_right_top">
                <div class="body_right_top_left">
                    <p class="right_top_left_title">Danh sách sản phẩm</p>
                </div>
                <div class="body_right_top_right">
                    <button class="add-new-item" onclick="document.location='ThemSanPham.php'"><i class="fas fa-plus"></i><a>Tạo sản phẩm</a></button>
                    <button class="post-excel" onclick="exportTableToExcel('infor-table', 'Danh Sách Sản Phẩm')"><i class="fas fa-download"></i>Xuất Excel</button>
                </div>
            </div>
            <div class="body_right_bottom">
                <div class="filter-zone">
                    <form action="" method="post">
                        <input type="search" name="SPsearch" id="search-txt" placeholder="Nhập tên sản phẩm cần tìm">
                        <button name="submit" type="submit" class="search-item"><i class="fas fa-search"></i>Tìm kiếm</button>
                    </form>
                </div>
                <div class="excel-table-zone">
                    <table id="infor-table">
                        <tr>
                            <th class="pro-col-1">Mã sản phẩm</th>
                            <th class="pro-col-2">Tên sản phẩm</th>
                            <th class="pro-col-3">Giá/Két</th>
                            <th class="pro-col-4">Giá/Lốc</th>
                            <th class="pro-col-5">Giá/Thùng</th>
                            <th class="pro-col-6">Nhà sản xuất</th>
                            <th class="pro-col-7">Số lượng</th>
                            <th class="pro-col-8"></th>
                        </tr>
                        <?php 
                            if(isset($_POST['submit']))
                                require './xuly/xulytimkiem.php';
                            else 
                                require './xuly/xulyshowSP.php';  
                        ?>
                        <!--<tr>
                            <td class="pro-col-1">SP001</td>
                            <td class="pro-col-2">Sting Hương Dâu</td>
                            <td class="pro-col-3">100.000</td>
                            <td class="pro-col-4">50.000</td>
                            <td class="pro-col-5">25.000</td>
                            <td class="pro-col-6">Sting</td>
                            <td class="pro-col-7">1900</td>
                            <td class="pro-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pro-col-1">SP002</td>
                            <td class="pro-col-2">Moutain Dew</td>
                            <td class="pro-col-3">80.000</td>
                            <td class="pro-col-4">40.000</td>
                            <td class="pro-col-5">20.000</td>
                            <td class="pro-col-6">Moutain Dew</td>
                            <td class="pro-col-7">850</td>
                            <td class="pro-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pro-col-1">SP003</td>
                            <td class="pro-col-2">Moutain Dew</td>
                            <td class="pro-col-3">80.000</td>
                            <td class="pro-col-4">40.000</td>
                            <td class="pro-col-5">20.000</td>
                            <td class="pro-col-6">Moutain Dew</td>
                            <td class="pro-col-7">850</td>
                            <td class="pro-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pro-col-1">SP004</td>
                            <td class="pro-col-2">Moutain Dew</td>
                            <td class="pro-col-3">80.000</td>
                            <td class="pro-col-4">40.000</td>
                            <td class="pro-col-5">20.000</td>
                            <td class="pro-col-6">Moutain Dew</td>
                            <td class="pro-col-7">850</td>
                            <td class="pro-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>
                        <tr>
                            <td class="pro-col-1">SP005</td>
                            <td class="pro-col-2">Moutain Dew</td>
                            <td class="pro-col-3">80.000</td>
                            <td class="pro-col-4">40.000</td>
                            <td class="pro-col-5">20.000</td>
                            <td class="pro-col-6">Moutain Dew</td>
                            <td class="pro-col-7">850</td>
                            <td class="pro-col-8">
                                <button class="contact-btn" title="Ghi chú"><i class="far fa-sticky-note"></i></button>
                                <button class="contact-btn" title="Điều chỉnh"><i class="fas fa-edit"></i></button>
                                <button class="contact-btn" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                            </td>
                        </tr>-->
                    </table>
                </div>
                <div class="count-total-zone">
                    <p>Tổng số sản phẩm: <?php echo $rowcount;?></p>
                </div>
            </div>
        </div>
    </div>
    <div class="footer">
        <p id="foot_txt">© Copyright 2021 TMTM Company. All rights reserved</p>
    </div>
</body>
</html>